"""Engine/session management and schema bootstrap (including audit-log triggers)."""
from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from config.settings import get_settings
from db.models import Base

logger = logging.getLogger(__name__)
_engine: Engine | None = None
_factory: sessionmaker[Session] | None = None


def configure_engine(url: str | None = None, *, echo: bool = False) -> Engine:
    """(Re)create the global engine. ``sqlite://`` gives an in-memory DB (used by tests)."""
    global _engine, _factory
    url = url or get_settings().database_url
    kwargs: dict = {"echo": echo, "future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
        if url in ("sqlite://", "sqlite:///:memory:"):
            kwargs["poolclass"] = StaticPool
    engine = create_engine(url, **kwargs)
    if url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def _pragmas(dbapi_conn, _record) -> None:  # noqa: ANN001
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.close()
    if _engine is not None:
        _engine.dispose()
    _engine = engine
    _factory = sessionmaker(bind=engine, expire_on_commit=False, future=True)
    return engine


def get_engine() -> Engine:
    return _engine or configure_engine()


def install_audit_triggers(engine: Engine, retention_days: int) -> None:
    """SQLite: forbid UPDATE always, and DELETE inside the retention window."""
    if engine.dialect.name != "sqlite":
        logger.warning("audit append-only triggers not installed for dialect=%s; "
                       "enforce with DB permissions instead", engine.dialect.name)
        return
    days = int(retention_days)  # int() guarantees no SQL is interpolated
    with engine.begin() as conn:
        conn.exec_driver_sql(
            "CREATE TRIGGER IF NOT EXISTS audit_log_no_update BEFORE UPDATE ON audit_log "
            "BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;")
        conn.exec_driver_sql(
            "CREATE TRIGGER IF NOT EXISTS audit_log_retention_delete BEFORE DELETE ON audit_log "
            f"WHEN OLD.ts > datetime('now', '-{days} days') "
            "BEGIN SELECT RAISE(ABORT, 'audit_log rows are protected during retention'); END;")


def init_db() -> None:
    """Create tables and audit triggers (idempotent)."""
    engine = get_engine()
    Base.metadata.create_all(engine)
    install_audit_triggers(engine, get_settings().audit_retention_days)


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope: commit on success, rollback on error."""
    if _factory is None:
        configure_engine()
    assert _factory is not None
    session = _factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@contextmanager
def optional_session(session: Session | None) -> Iterator[Session]:
    """Reuse the caller's session/transaction if given, else open a new scope."""
    if session is not None:
        yield session
    else:
        with session_scope() as s:
            yield s
