"""SQLAlchemy models. The audit_log table is append-only (ORM guards + SQLite triggers)."""
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import (Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, String,
                        Text, event)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    """Naive UTC timestamp (SQLite stores naive datetimes)."""
    return datetime.now(UTC).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    __table_args__ = (CheckConstraint(
        "role IN ('admin','planner','traveler','auditor')", name="ck_users_role"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(80), default="")
    password_hash: Mapped[str] = mapped_column(String(128))
    role: Mapped[str] = mapped_column(String(16))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class PlannerAssignment(Base):
    """Which travelers (clients) a planner may read."""

    __tablename__ = "planner_assignments"
    planner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    traveler_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)


class Itinerary(Base):
    """Preferences and content are encrypted at rest (Fernet)."""

    __tablename__ = "itineraries"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(120))
    destination: Mapped[str] = mapped_column(String(60))
    generator_model: Mapped[str] = mapped_column(String(100))
    preferences_enc: Mapped[str] = mapped_column(Text)
    content_enc: Mapped[str] = mapped_column(Text)
    metrics_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    request_id: Mapped[str] = mapped_column(String(32), default="-")
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)  # no FK on purpose
    role: Mapped[str | None] = mapped_column(String(16), nullable=True)
    action: Mapped[str] = mapped_column(String(64), index=True)
    resource: Mapped[str] = mapped_column(String(200), default="")
    outcome: Mapped[str] = mapped_column(String(16))
    flags: Mapped[str] = mapped_column(Text, default="[]")
    detail: Mapped[str] = mapped_column(String(500), default="")


class EvaluationRun(Base):
    __tablename__ = "evaluation_runs"
    __table_args__ = (Index("ix_eval_run_model", "run_id", "generator_model"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(String(32), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    generator_model: Mapped[str] = mapped_column(String(100))
    judge_model: Mapped[str] = mapped_column(String(100))
    case_id: Mapped[str] = mapped_column(String(40))
    category: Mapped[str] = mapped_column(String(20), default="standard")
    metrics_json: Mapped[str] = mapped_column(Text, default="{}")
    judge_json: Mapped[str] = mapped_column(Text, default="{}")
    config_hash: Mapped[str] = mapped_column(String(64), default="")
    self_judged: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[int | None] = mapped_column(Integer, nullable=True)


class UsageEvent(Base):
    """Per-user usage for rate limiting and role budget caps."""

    __tablename__ = "usage_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    kind: Mapped[str] = mapped_column(String(24))
    tokens: Mapped[int] = mapped_column(Integer, default=0)


class AuditImmutableError(RuntimeError):
    """Raised on any attempt to modify or delete an audit record via the ORM."""


@event.listens_for(AuditLog, "before_update")
@event.listens_for(AuditLog, "before_delete")
def _audit_guard(mapper, connection, target) -> None:  # noqa: ANN001
    raise AuditImmutableError("audit_log is append-only")
