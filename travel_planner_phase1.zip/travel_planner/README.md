# Travel Itinerary Planner and Optimizer (secure LLM agent)

**Status: Phase 1 of 4 (foundation).** Planner graph, UI pages and the evaluation matrix arrive in Phases 2-4.

## Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt          # then run: pip-audit   (pins are unverified, see requirements.txt)
cp .env.example .env                         # fill LLM_API_KEY and DATA_ENCRYPTION_KEY
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"   # -> DATA_ENCRYPTION_KEY
python scripts/create_admin.py --username admin   # prompts for the password
pytest                                        # no network needed (LLM is mocked)
bandit -r . -x tests && pip-audit             # security scans
# Phase 3+: streamlit run app.py
```

## Layout (Phase 1)
- `config/`: settings, model registry, LLM factories, `invoke_structured`, schemas, validated data loader
- `security/`: RBAC, auth/lockout/idle timeout, audit (append-only), PII, guardrails + `guardrails.yaml`, crypto, rate limits, redacting logs
- `db/`: SQLAlchemy models (users, itineraries, audit_log, evaluation_runs, usage_events)
- `data/`, `eval/`: sample data for Paris/Tokyo/Jaipur (illustrative, approximate) and 10 benchmark cases
- `tests/`: pii, injection corpus, detectors, guardrails, RBAC matrix, audit, auth, structured output, models, data store

## RBAC matrix
Generated from code by `security.rbac.permissions_matrix_markdown()` and checked by `tests/test_rbac.py`.

| Permission | admin | planner | traveler | auditor |
|---|---|---|---|---|
| itinerary:create | yes | yes | yes | no |
| itinerary:read_own | yes | yes | yes | no |
| itinerary:read_all | yes | yes (assigned clients) | no | yes (read-only, redacted) |
| itinerary:export | yes | yes | yes | no |
| model:select | yes | yes (generator only, allow-list) | no | no |
| evaluation:view | yes | yes | no | yes |
| evaluation:run | yes | no | no | no |
| data:manage | yes | no | no | no |
| user:manage | yes | no | no | no |
| audit:view | yes | no | no | yes |
| config:view_security | yes | no | no | yes |
| model:configure (added: admin-only settings/connection test) | yes | no | no | no |
