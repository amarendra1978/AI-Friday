"""Login, lockout and idle-timeout session handling.

``authenticate`` / ``session_expired`` are pure service logic (unit-testable). The Streamlit
glue at the bottom imports streamlit lazily. Streamlit sessions are server-side
(``st.session_state``); the browser holds only Streamlit's own session cookie, so terminate
TLS at a reverse proxy and set secure/HttpOnly cookie attributes there.
"""
from __future__ import annotations

import logging
import secrets
import time
from dataclasses import dataclass
from datetime import timedelta
from functools import lru_cache

from config.settings import get_settings
from db.models import User, utcnow
from db.session import optional_session, session_scope
from security import audit
from security.context import new_request_id
from security.passwords import hash_password, verify_password
from security.rbac import Principal, Role
from security.users import normalize_username

logger = logging.getLogger(__name__)
GENERIC_FAILURE = "Invalid username or password, or the account is temporarily locked."
SESSION_KEY = "_auth"


@dataclass(frozen=True, slots=True)
class AuthResult:
    ok: bool
    principal: Principal | None
    message: str


@lru_cache(maxsize=1)
def _dummy_hash() -> str:
    """Hash verified for unknown users so timing does not reveal which usernames exist."""
    return hash_password(secrets.token_urlsafe(16))


def authenticate(username: str, password: str, *, session=None) -> AuthResult:  # noqa: ANN001
    """Verify credentials with lockout after N failures. Never reveals why a login failed."""
    settings = get_settings()
    username = normalize_username(username)[:64]
    now = utcnow()
    with optional_session(session) as s:
        user = s.query(User).filter(User.username == username).one_or_none()
        if user is None:
            verify_password(password, _dummy_hash())
            audit.record("auth:login", "failure", flags=["unknown_user"], session=s)
            return AuthResult(False, None, GENERIC_FAILURE)
        if not user.is_active or (user.locked_until and user.locked_until > now):
            verify_password(password, _dummy_hash())
            audit.record("auth:login", "denied", user_id=user.id, role=user.role,
                         flags=["locked_or_inactive"], session=s)
            return AuthResult(False, None, GENERIC_FAILURE)
        if not verify_password(password, user.password_hash):
            user.failed_attempts += 1
            flags = ["bad_password"]
            if user.failed_attempts >= settings.max_failed_logins:
                user.locked_until = now + timedelta(minutes=settings.lockout_minutes)
                user.failed_attempts = 0
                flags.append("account_locked")
            audit.record("auth:login", "failure", user_id=user.id, role=user.role,
                         flags=flags, session=s)
            return AuthResult(False, None, GENERIC_FAILURE)
        user.failed_attempts, user.locked_until, user.last_login_at = 0, None, now
        audit.record("auth:login", "success", user_id=user.id, role=user.role, session=s)
        return AuthResult(True, Principal(user.id, user.username, Role(user.role)), "")


def session_expired(last_seen: float, now: float, idle_minutes: int) -> bool:
    """True if the session has been idle longer than the timeout."""
    return (now - last_seen) > idle_minutes * 60


# ----------------------------------------------------------------------------- Streamlit glue
def _store_session(principal: Principal) -> None:
    import streamlit as st

    st.session_state.clear()  # drop anything left from a previous identity
    st.session_state[SESSION_KEY] = {
        "user_id": principal.user_id, "username": principal.username,
        "role": principal.role.value, "last_seen": time.time(),
        "session_id": secrets.token_urlsafe(16),
    }


def logout(reason: str = "logout") -> None:
    """Audit and clear all session state."""
    import streamlit as st

    data = st.session_state.get(SESSION_KEY)
    if data:
        try:
            audit.record("auth:logout", "success", user_id=data["user_id"], role=data["role"],
                         flags=[reason])
        except Exception:
            logger.exception("could not audit logout")
    st.session_state.clear()


def current_principal() -> Principal | None:
    """Return the logged-in principal, enforcing idle timeout and re-checking the account."""
    import streamlit as st

    data = st.session_state.get(SESSION_KEY)
    if not data:
        return None
    now = time.time()
    if session_expired(data["last_seen"], now, get_settings().session_idle_minutes):
        logout("idle_timeout")
        st.session_state["_notice"] = "Your session expired. Please sign in again."
        return None
    with session_scope() as s:
        user = s.get(User, data["user_id"])
        valid = user is not None and user.is_active and user.role == data["role"]
    if not valid:  # deactivated or role changed since login
        logout("account_changed")
        return None
    data["last_seen"] = now
    return Principal(data["user_id"], data["username"], Role(data["role"]))


def require_login() -> Principal:
    """Gate for every page: render the login form and stop unless authenticated."""
    import streamlit as st

    principal = current_principal()
    if principal is not None:
        return principal
    new_request_id()
    st.title("Travel Itinerary Planner")
    if notice := st.session_state.pop("_notice", None):
        st.info(notice)
    with st.form("login_form"):
        username = st.text_input("Username", max_chars=32)
        password = st.text_input("Password", type="password", max_chars=72)
        submitted = st.form_submit_button("Sign in")
    if submitted:
        result = authenticate(username, password)
        if result.ok and result.principal is not None:
            _store_session(result.principal)
            st.rerun()
        st.error(result.message)
    st.stop()


def render_sidebar_user(principal: Principal) -> None:
    """Show who is signed in and a logout button."""
    import streamlit as st

    st.sidebar.markdown(f"**{principal.username}** ({principal.role.value})")
    if st.sidebar.button("Log out"):
        logout()
        st.rerun()
