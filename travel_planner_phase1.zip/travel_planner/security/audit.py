"""Append-only audit logging. Details are PII-redacted before they are written."""
from __future__ import annotations

import csv
import io
import json
import logging
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

from sqlalchemy import select
from sqlalchemy.orm import Session

from db.models import AuditLog
from db.session import optional_session
from security.context import get_request_id
from security.logging_setup import redact_secrets
from security.rbac import Principal, add_denial_hook, require_permission

logger = logging.getLogger(__name__)
Outcome = Literal["success", "denied", "blocked", "failure", "flagged"]
_MAX_DETAIL = 500


def record(action: str, outcome: Outcome, *, principal: Principal | None = None,
           user_id: int | None = None, role: str | None = None, resource: str = "",
           flags: Iterable[str] = (), detail: str = "", request_id: str | None = None,
           session: Session | None = None) -> None:
    """Write one audit event. Raises on failure so security-relevant actions can fail closed."""
    if principal is not None:
        user_id, role = principal.user_id, principal.role.value
    clean_flags = [str(f)[:80] for f in flags][:50]
    row = AuditLog(
        request_id=(request_id or get_request_id())[:32],
        user_id=user_id, role=role, action=action[:64], resource=resource[:200],
        outcome=outcome, flags=json.dumps(clean_flags),
        detail=redact_secrets(detail)[:_MAX_DETAIL],
    )
    with optional_session(session) as s:
        s.add(row)
        s.flush()


def _denial_to_audit(principal: Principal | None, permission: str, target: str) -> None:
    record("access:denied", "denied", principal=principal, resource=target[:200],
           flags=[f"permission:{permission}"])


def install_rbac_hook() -> None:
    """Make every RBAC denial an audit event. Call once at app start."""
    add_denial_hook(_denial_to_audit)


@dataclass(frozen=True, slots=True)
class AuditEventView:
    id: int
    ts: datetime
    request_id: str
    user_id: int | None
    role: str | None
    action: str
    resource: str
    outcome: str
    flags: list[str]
    detail: str


def _query(session: Session, *, limit: int, action: str | None, user_id: int | None,
           since: datetime | None) -> list[AuditEventView]:
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(max(1, min(limit, 5000)))
    if action:
        stmt = stmt.where(AuditLog.action == action)
    if user_id is not None:
        stmt = stmt.where(AuditLog.user_id == user_id)
    if since is not None:
        stmt = stmt.where(AuditLog.ts >= since)
    return [AuditEventView(r.id, r.ts, r.request_id, r.user_id, r.role, r.action, r.resource,
                           r.outcome, json.loads(r.flags or "[]"), r.detail)
            for r in session.scalars(stmt)]


@require_permission("audit:view")
def list_events(principal: Principal, *, limit: int = 200, action: str | None = None,
                user_id: int | None = None, since: datetime | None = None,
                session: Session | None = None) -> list[AuditEventView]:
    """Newest-first audit events (admin and auditor)."""
    with optional_session(session) as s:
        return _query(s, limit=limit, action=action, user_id=user_id, since=since)


def _csv_safe(value: object) -> str:
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text  # CSV-injection guard


@require_permission("audit:view")
def export_events_csv(principal: Principal, *, limit: int = 5000, session: Session | None = None) -> str:
    """CSV export; the export itself is audit-logged."""
    with optional_session(session) as s:
        events = _query(s, limit=limit, action=None, user_id=None, since=None)
        record("audit:export", "success", principal=principal, resource="audit_log",
               detail=f"rows={len(events)}", session=s)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "timestamp_utc", "request_id", "user_id", "role", "action",
                     "resource", "outcome", "flags", "detail"])
    for e in events:
        writer.writerow([_csv_safe(x) for x in (e.id, e.ts.isoformat(), e.request_id, e.user_id,
                                                e.role, e.action, e.resource, e.outcome,
                                                ";".join(e.flags), e.detail)])
    return buf.getvalue()
