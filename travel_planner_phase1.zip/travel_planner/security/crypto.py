"""Field-level encryption at rest (Fernet). Fails closed if the key is missing or invalid."""
from __future__ import annotations

import os
from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken


class CryptoConfigError(RuntimeError):
    """DATA_ENCRYPTION_KEY is missing or invalid."""


class DecryptionError(RuntimeError):
    """Ciphertext could not be decrypted (wrong key or tampering)."""


@lru_cache(maxsize=2)
def _fernet(key: str) -> Fernet:
    try:
        return Fernet(key.encode())
    except (ValueError, TypeError):
        raise CryptoConfigError("DATA_ENCRYPTION_KEY is not a valid Fernet key") from None


def _current() -> Fernet:
    key = os.getenv("DATA_ENCRYPTION_KEY", "")
    if not key:
        raise CryptoConfigError("DATA_ENCRYPTION_KEY is not set")
    return _fernet(key)


def encrypt_text(plain: str) -> str:
    return _current().encrypt(plain.encode("utf-8")).decode("ascii")


def decrypt_text(token: str) -> str:
    try:
        return _current().decrypt(token.encode("ascii")).decode("utf-8")
    except (InvalidToken, UnicodeError):
        raise DecryptionError("Stored data could not be decrypted") from None


def generate_key() -> str:
    return Fernet.generate_key().decode("ascii")
