"""Roles, permissions and the ``require_permission`` decorator. Deny by default.

Service functions must take the acting :class:`Principal` as their first positional argument
or as ``principal=``. Anything else is denied.
"""
from __future__ import annotations

import functools
import logging
from collections.abc import Callable, Collection
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal, ParamSpec, TypeVar

from config.models import PLANNER_GENERATOR_ALLOWLIST, chat_models

logger = logging.getLogger(__name__)
P = ParamSpec("P")
R = TypeVar("R")


class Role(StrEnum):
    ADMIN = "admin"
    PLANNER = "planner"
    TRAVELER = "traveler"
    AUDITOR = "auditor"


class Permission(StrEnum):
    ITINERARY_CREATE = "itinerary:create"
    ITINERARY_READ_OWN = "itinerary:read_own"
    ITINERARY_READ_ALL = "itinerary:read_all"
    ITINERARY_EXPORT = "itinerary:export"
    MODEL_SELECT = "model:select"
    EVALUATION_VIEW = "evaluation:view"
    EVALUATION_RUN = "evaluation:run"
    DATA_MANAGE = "data:manage"
    USER_MANAGE = "user:manage"
    AUDIT_VIEW = "audit:view"
    CONFIG_VIEW_SECURITY = "config:view_security"
    MODEL_CONFIGURE = "model:configure"  # admin-only extra: change model settings, test connection


_P = Permission
ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.ADMIN: frozenset(Permission),
    Role.PLANNER: frozenset({_P.ITINERARY_CREATE, _P.ITINERARY_READ_OWN, _P.ITINERARY_READ_ALL,
                             _P.ITINERARY_EXPORT, _P.MODEL_SELECT, _P.EVALUATION_VIEW}),
    Role.TRAVELER: frozenset({_P.ITINERARY_CREATE, _P.ITINERARY_READ_OWN, _P.ITINERARY_EXPORT}),
    Role.AUDITOR: frozenset({_P.ITINERARY_READ_ALL, _P.EVALUATION_VIEW, _P.AUDIT_VIEW,
                             _P.CONFIG_VIEW_SECURITY}),
}

Scope = Literal["all", "assigned"]
READ_ALL_SCOPE: dict[Role, Scope] = {Role.ADMIN: "all", Role.PLANNER: "assigned", Role.AUDITOR: "all"}
READ_ALL_REDACTED: frozenset[Role] = frozenset({Role.AUDITOR})

# Streamlit page -> permission required to see it (each page also calls require_permission).
PAGE_PERMISSIONS: dict[str, Permission] = {
    "Planner": _P.ITINERARY_CREATE,
    "My Itineraries": _P.ITINERARY_READ_OWN,
    "Evaluation Matrix": _P.EVALUATION_VIEW,
    "Audit Log": _P.AUDIT_VIEW,
    "Admin": _P.USER_MANAGE,
}


class PermissionDenied(Exception):
    """Raised when the acting user lacks a permission. Message is safe to show in the UI."""


@dataclass(frozen=True, slots=True)
class Principal:
    user_id: int
    username: str
    role: Role


def _coerce_role(role: object) -> Role | None:
    try:
        return Role(role)
    except ValueError:
        return None


def has_permission(principal: Principal | None, permission: Permission | str) -> bool:
    """True only if the principal's role explicitly grants the permission."""
    if not isinstance(principal, Principal):
        return False
    role = _coerce_role(principal.role)
    try:
        perm = Permission(permission)
    except ValueError:
        return False
    return role is not None and perm in ROLE_PERMISSIONS.get(role, frozenset())


_denial_hooks: list[Callable[[Principal | None, str, str], None]] = []


def add_denial_hook(hook: Callable[[Principal | None, str, str], None]) -> None:
    """Register a callback invoked on every denial (used to write audit events)."""
    if hook not in _denial_hooks:
        _denial_hooks.append(hook)


def _notify(principal: Principal | None, permission: str, target: str) -> None:
    logger.warning("permission denied permission=%s target=%s user_id=%s", permission, target,
                   getattr(principal, "user_id", None))
    for hook in _denial_hooks:
        try:
            hook(principal, permission, target)
        except Exception:  # a failing hook must never turn a denial into an allow
            logger.exception("denial hook failed")


def require_permission(permission: Permission | str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Decorator enforcing a permission in the service layer. Unknown permissions fail at import."""
    perm = Permission(permission)

    def decorator(fn: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            principal = kwargs["principal"] if "principal" in kwargs else (args[0] if args else None)
            if not has_permission(principal if isinstance(principal, Principal) else None, perm):
                _notify(principal if isinstance(principal, Principal) else None, perm.value,
                        fn.__qualname__)
                raise PermissionDenied("You do not have permission to perform this action.")
            return fn(*args, **kwargs)

        wrapper.required_permission = perm  # type: ignore[attr-defined]
        return wrapper

    return decorator


def require_page_access(principal: Principal | None, page: str) -> None:
    """Call at the top of every Streamlit page. Raises PermissionDenied."""
    perm = PAGE_PERMISSIONS.get(page)
    if perm is None or not has_permission(principal, perm):
        _notify(principal, perm.value if perm else "unknown-page", f"page:{page}")
        raise PermissionDenied("You do not have access to this page.")


def visible_pages(principal: Principal | None) -> list[str]:
    return [page for page, perm in PAGE_PERMISSIONS.items() if has_permission(principal, perm)]


@dataclass(frozen=True, slots=True)
class ItineraryAccess:
    level: Literal["full", "redacted"]


def resolve_itinerary_access(principal: Principal, owner_id: int,
                             assigned_client_ids: Collection[int] = ()) -> ItineraryAccess | None:
    """Row-level read access to one itinerary, or None (deny)."""
    if principal.user_id == owner_id and has_permission(principal, _P.ITINERARY_READ_OWN):
        return ItineraryAccess("full")
    if not has_permission(principal, _P.ITINERARY_READ_ALL):
        return None
    role = _coerce_role(principal.role)
    scope = READ_ALL_SCOPE.get(role) if role else None
    if scope == "all" or (scope == "assigned" and owner_id in assigned_client_ids):
        return ItineraryAccess("redacted" if role in READ_ALL_REDACTED else "full")
    return None


def can_delete_itinerary(principal: Principal, owner_id: int) -> bool:
    """Users may delete only their own itineraries."""
    return principal.user_id == owner_id and has_permission(principal, _P.ITINERARY_READ_OWN)


ModelPurpose = Literal["generator", "judge", "eval_candidate"]


def allowed_generator_models(principal: Principal) -> tuple[str, ...]:
    """Models this principal may choose as generator."""
    if not has_permission(principal, _P.MODEL_SELECT):
        return ()
    if principal.role == Role.ADMIN:
        return tuple(m.name for m in chat_models())
    return PLANNER_GENERATOR_ALLOWLIST


def can_select_model(principal: Principal, model_name: str, purpose: ModelPurpose = "generator") -> bool:
    """Planners: generator only, from the allow-list. Judge/eval selection is admin-only."""
    if purpose == "generator":
        return model_name in allowed_generator_models(principal)
    return principal.role == Role.ADMIN and has_permission(principal, _P.EVALUATION_RUN) \
        and model_name in {m.name for m in chat_models()}


def permissions_matrix_markdown() -> str:
    """Render the RBAC matrix for the README (generated, so it cannot drift from the code)."""
    roles = list(Role)
    lines = ["| Permission | " + " | ".join(r.value for r in roles) + " |",
             "|---|" + "---|" * len(roles)]
    for perm in Permission:
        cells = []
        for r in roles:
            if perm not in ROLE_PERMISSIONS[r]:
                cells.append("no")
            elif perm == _P.ITINERARY_READ_ALL and READ_ALL_SCOPE.get(r) == "assigned":
                cells.append("yes (assigned clients)")
            elif perm == _P.ITINERARY_READ_ALL and r in READ_ALL_REDACTED:
                cells.append("yes (read-only, redacted)")
            elif perm == _P.MODEL_SELECT and r == Role.PLANNER:
                cells.append("yes (generator only, allow-list)")
            else:
                cells.append("yes")
        lines.append(f"| {perm.value} | " + " | ".join(cells) + " |")
    return "\n".join(lines)
