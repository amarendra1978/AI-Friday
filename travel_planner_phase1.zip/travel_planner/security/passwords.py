"""bcrypt password hashing and password policy."""
from __future__ import annotations

import bcrypt

MIN_LENGTH = 12
MAX_BYTES = 72  # bcrypt ignores bytes beyond 72, so longer passwords are rejected, not truncated
_COST = 12


def validate_password_policy(password: str, *, username: str = "") -> list[str]:
    """Return human-readable problems (empty list = acceptable)."""
    problems: list[str] = []
    if len(password) < MIN_LENGTH:
        problems.append(f"at least {MIN_LENGTH} characters")
    if len(password.encode("utf-8")) > MAX_BYTES:
        problems.append(f"at most {MAX_BYTES} bytes")
    classes = sum(bool(any(f(c) for c in password)) for f in
                  (str.islower, str.isupper, str.isdigit, lambda c: not c.isalnum()))
    if classes < 3:
        problems.append("use at least 3 of: lowercase, uppercase, digits, symbols")
    if username and len(username) >= 3 and username.lower() in password.lower():
        problems.append("must not contain the username")
    return problems


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=_COST)).decode("ascii")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8")[:MAX_BYTES], hashed.encode("ascii"))
    except (ValueError, TypeError):
        return False
