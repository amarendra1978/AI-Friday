"""Per-request correlation id shared by audit records and logs."""
from __future__ import annotations

import uuid
from contextvars import ContextVar

request_id_var: ContextVar[str] = ContextVar("request_id", default="-")


def new_request_id() -> str:
    """Start a new request scope and return its id."""
    rid = uuid.uuid4().hex
    request_id_var.set(rid)
    return rid


def get_request_id() -> str:
    return request_id_var.get()
