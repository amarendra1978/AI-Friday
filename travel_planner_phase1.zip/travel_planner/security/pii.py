"""PII detection and redaction (stdlib only).

Detects emails, phone numbers, card numbers (regex + Luhn), passport / national-ID
numbers. Placeholders never contain the original value.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class PiiMatch:
    kind: str
    start: int
    end: int


@dataclass(frozen=True, slots=True)
class RedactionResult:
    text: str
    counts: dict[str, int] = field(default_factory=dict)

    @property
    def found(self) -> bool:
        return bool(self.counts)


_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
_CARD = re.compile(r"(?<![\w-])(?:\d[ -]?){12,18}\d(?![\w-])")
_SSN = re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)")
_AADHAAR = re.compile(r"(?<!\d)\d{4}[ -]\d{4}[ -]\d{4}(?!\d)")
_PAN = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
_PASSPORT = re.compile(
    r"\bpassport(?:\s*(?:no\.?|number|num|#))?\s*[:#-]?\s*([A-Z0-9]{6,9})\b", re.I)
_NATIONAL_ID = re.compile(
    r"\b(?:national\s+id|id\s+card|driver.?s?\s+licen[cs]e|ssn|aadhaar|aadhar)"
    r"(?:\s*(?:no\.?|number|num|#))?\s*[:#-]?\s*([A-Z0-9][A-Z0-9-]{5,19})\b", re.I)
_PHONE_CAND = re.compile(r"(?<![\w.])\+?\d[\d\s().-]{6,18}\d(?!\w)")
_DATE_LIKE = re.compile(r"^(?:\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})")
_PHONE_KW = re.compile(r"\b(?:phone|call|mobile|cell|whatsapp|tel|contact|reach)\b[^\d]{0,15}$", re.I)


def luhn_valid(number: str) -> bool:
    """Return True if the digits in ``number`` pass the Luhn checksum (13-19 digits)."""
    digits = [int(c) for c in number if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _is_phone(text: str, m: re.Match[str]) -> bool:
    cand = m.group().strip()
    digits = re.sub(r"\D", "", cand)
    if not 9 <= len(digits) <= 15 or _DATE_LIKE.match(cand):
        return False
    if cand.startswith("+"):
        return True
    seps = len(re.findall(r"[\s().-]", cand))
    if seps >= 2:
        return True
    # 10 contiguous digits count only when a phone-ish keyword precedes them.
    before = text[max(0, m.start() - 20):m.start()]
    return len(digits) == 10 and bool(_PHONE_KW.search(before))


# Lower number wins when matches overlap.
_PRIORITY = {"card": 0, "national_id": 1, "passport": 2, "email": 3, "phone": 4}


def detect_pii(text: str) -> list[PiiMatch]:
    """Find non-overlapping PII spans, sorted by position."""
    found: list[PiiMatch] = []
    for m in _CARD.finditer(text):
        if luhn_valid(m.group()):
            found.append(PiiMatch("card", m.start(), m.end()))
    for pat in (_SSN, _AADHAAR, _PAN):
        found += [PiiMatch("national_id", m.start(), m.end()) for m in pat.finditer(text)]
    for pat, kind in ((_PASSPORT, "passport"), (_NATIONAL_ID, "national_id")):
        for m in pat.finditer(text):
            if any(c.isdigit() for c in m.group(1)):
                found.append(PiiMatch(kind, m.start(1), m.end(1)))
    found += [PiiMatch("email", m.start(), m.end()) for m in _EMAIL.finditer(text)]
    found += [PiiMatch("phone", m.start(), m.end())
              for m in _PHONE_CAND.finditer(text) if _is_phone(text, m)]

    found.sort(key=lambda p: (_PRIORITY[p.kind], p.start))
    accepted: list[PiiMatch] = []
    for cand in found:
        if all(cand.end <= a.start or cand.start >= a.end for a in accepted):
            accepted.append(cand)
    return sorted(accepted, key=lambda p: p.start)


def redact(text: str) -> RedactionResult:
    """Replace PII with ``[REDACTED_<KIND>]`` and report counts per kind."""
    matches = detect_pii(text)
    counts: dict[str, int] = {}
    out = text
    for m in reversed(matches):
        out = f"{out[:m.start]}[REDACTED_{m.kind.upper()}]{out[m.end:]}"
    for m in matches:
        counts[m.kind] = counts.get(m.kind, 0) + 1
    return RedactionResult(out, counts)


def contains_pii(text: str) -> bool:
    return bool(detect_pii(text))
