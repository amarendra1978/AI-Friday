"""Structured logging that redacts secrets and PII from every line, including tracebacks."""
from __future__ import annotations

import logging
import os
import re

from security.context import get_request_id
from security.pii import redact

_SECRET_ENV_NAMES = ("LLM_API_KEY", "DATA_ENCRYPTION_KEY")
_runtime_secrets: set[str] = set()
_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{12,}", re.I),
    re.compile(r"(?i)\b(api[_-]?key|secret|token|password)(['\"]?\s*[:=]\s*['\"]?)[^\s'\",;]{4,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
)


def register_secret(value: str) -> None:
    """Make sure a runtime-supplied secret (e.g. admin key override) is masked in logs."""
    if value and len(value) >= 6:
        _runtime_secrets.add(value)


def redact_secrets(text: str) -> str:
    """Mask known secret values, secret-looking patterns, and PII."""
    known = {os.getenv(n, "") for n in _SECRET_ENV_NAMES} | _runtime_secrets
    for secret in sorted((s for s in known if len(s) >= 6), key=len, reverse=True):
        text = text.replace(secret, "[REDACTED_SECRET]")
    for pat in _PATTERNS:
        if pat.groups >= 2:
            text = pat.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED_SECRET]", text)
        else:
            text = pat.sub("[REDACTED_SECRET]", text)
    return redact(text).text


class RedactingFormatter(logging.Formatter):
    """Formatter that redacts after formatting so exception traces are covered too."""

    def format(self, record: logging.LogRecord) -> str:
        record.request_id = get_request_id()
        return redact_secrets(super().format(record))


def configure_logging(level: str = "INFO") -> None:
    """Idempotently install the redacting handler on the root logger."""
    root = logging.getLogger()
    if any(getattr(h, "_tp_handler", False) for h in root.handlers):
        return
    handler = logging.StreamHandler()
    handler._tp_handler = True  # type: ignore[attr-defined]
    handler.setFormatter(RedactingFormatter(
        "%(asctime)s %(levelname)s %(name)s rid=%(request_id)s %(message)s"))
    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
