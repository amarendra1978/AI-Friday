"""User-management service layer (admin only, audited) and assignment helpers."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from db.models import PlannerAssignment, User
from db.session import optional_session
from security import audit
from security.passwords import hash_password, validate_password_policy
from security.rbac import Principal, Role, require_permission

USERNAME_RE = re.compile(r"^[a-z0-9_.-]{3,32}$")


class UserError(ValueError):
    """Validation problem with a safe, user-presentable message."""


@dataclass(frozen=True, slots=True)
class UserView:
    id: int
    username: str
    display_name: str
    role: str
    is_active: bool
    last_login_at: datetime | None


def normalize_username(username: str) -> str:
    return username.strip().lower()


def _create_row(session: Session, username: str, password: str, role: Role, display_name: str) -> User:
    username = normalize_username(username)
    if not USERNAME_RE.match(username):
        raise UserError("Username must be 3-32 chars: letters, digits, '.', '_' or '-'.")
    problems = validate_password_policy(password, username=username)
    if problems:
        raise UserError("Password too weak: " + "; ".join(problems))
    user = User(username=username, display_name=display_name.strip()[:80],
                password_hash=hash_password(password), role=Role(role).value)
    session.add(user)
    try:
        session.flush()
    except IntegrityError:
        session.rollback()
        raise UserError("That username is not available.") from None
    return user


def bootstrap_admin(username: str, password: str) -> int:
    """Create an admin WITHOUT a principal. For scripts/create_admin.py only (server access)."""
    with optional_session(None) as s:
        user = _create_row(s, username, password, Role.ADMIN, "Administrator")
        audit.record("user:bootstrap_admin", "success", user_id=user.id, role="admin",
                     resource=f"user:{user.id}", session=s)
        return user.id


@require_permission("user:manage")
def create_user(principal: Principal, username: str, password: str, role: Role,
                display_name: str = "", *, session: Session | None = None) -> int:
    with optional_session(session) as s:
        user = _create_row(s, username, password, role, display_name)
        audit.record("user:create", "success", principal=principal, resource=f"user:{user.id}",
                     detail=f"role={Role(role).value}", session=s)
        return user.id


@require_permission("user:manage")
def list_users(principal: Principal, *, session: Session | None = None) -> list[UserView]:
    with optional_session(session) as s:
        return [UserView(u.id, u.username, u.display_name, u.role, u.is_active, u.last_login_at)
                for u in s.scalars(select(User).order_by(User.id))]


def _active_admin_count(s: Session) -> int:
    return s.scalar(select(func.count()).select_from(User)
                    .where(User.role == "admin", User.is_active.is_(True))) or 0


def _get(s: Session, user_id: int) -> User:
    user = s.get(User, user_id)
    if user is None:
        raise UserError("User not found.")
    return user


@require_permission("user:manage")
def set_user_active(principal: Principal, user_id: int, active: bool, *,
                    session: Session | None = None) -> None:
    with optional_session(session) as s:
        user = _get(s, user_id)
        if not active and user.role == "admin" and user.is_active and _active_admin_count(s) <= 1:
            raise UserError("Cannot deactivate the last active admin.")
        user.is_active = active
        if active:
            user.failed_attempts, user.locked_until = 0, None
        audit.record("user:set_active", "success", principal=principal,
                     resource=f"user:{user_id}", detail=f"active={active}", session=s)


@require_permission("user:manage")
def change_role(principal: Principal, user_id: int, new_role: Role, *,
                session: Session | None = None) -> None:
    with optional_session(session) as s:
        user = _get(s, user_id)
        if user.role == "admin" and Role(new_role) != Role.ADMIN and user.is_active \
                and _active_admin_count(s) <= 1:
            raise UserError("Cannot demote the last active admin.")
        old, user.role = user.role, Role(new_role).value
        audit.record("user:change_role", "success", principal=principal,
                     resource=f"user:{user_id}", detail=f"{old}->{user.role}", session=s)


@require_permission("user:manage")
def reset_password(principal: Principal, user_id: int, new_password: str, *,
                   session: Session | None = None) -> None:
    with optional_session(session) as s:
        user = _get(s, user_id)
        problems = validate_password_policy(new_password, username=user.username)
        if problems:
            raise UserError("Password too weak: " + "; ".join(problems))
        user.password_hash = hash_password(new_password)
        user.failed_attempts, user.locked_until = 0, None
        audit.record("user:reset_password", "success", principal=principal,
                     resource=f"user:{user_id}", session=s)


@require_permission("user:manage")
def assign_client(principal: Principal, planner_id: int, traveler_id: int, *,
                  session: Session | None = None) -> None:
    """Let a planner read a traveler's itineraries."""
    with optional_session(session) as s:
        planner, traveler = _get(s, planner_id), _get(s, traveler_id)
        if planner.role != "planner" or traveler.role != "traveler":
            raise UserError("Assignment must be planner -> traveler.")
        if s.get(PlannerAssignment, (planner_id, traveler_id)) is None:
            s.add(PlannerAssignment(planner_id=planner_id, traveler_id=traveler_id))
        audit.record("user:assign_client", "success", principal=principal,
                     resource=f"planner:{planner_id}->traveler:{traveler_id}", session=s)


def get_assigned_client_ids(session: Session, planner_id: int) -> set[int]:
    """Internal helper for row-level checks."""
    return set(session.scalars(select(PlannerAssignment.traveler_id)
                               .where(PlannerAssignment.planner_id == planner_id)))
