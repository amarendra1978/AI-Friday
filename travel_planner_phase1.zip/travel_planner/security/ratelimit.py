"""Per-user generation limits and per-role daily token budgets."""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from config.settings import ROLE_LIMITS
from db.models import UsageEvent, utcnow
from db.session import optional_session
from security.rbac import Principal


class RateLimitExceeded(Exception):
    """Quota exceeded. Message is safe to show in the UI."""


def enforce_generation_quota(principal: Principal, *, session: Session | None = None) -> None:
    """Raise :class:`RateLimitExceeded` if the user is over the hourly or daily-token cap."""
    limits = ROLE_LIMITS.get(principal.role.value)
    if limits is None or limits.generations_per_hour <= 0:
        raise RateLimitExceeded("Your role cannot generate itineraries.")
    now = utcnow()
    with optional_session(session) as s:
        count = s.scalar(select(func.count()).select_from(UsageEvent).where(
            UsageEvent.user_id == principal.user_id, UsageEvent.kind == "generation",
            UsageEvent.ts >= now - timedelta(hours=1))) or 0
        if count >= limits.generations_per_hour:
            raise RateLimitExceeded(
                f"Hourly limit of {limits.generations_per_hour} generations reached. Try again later.")
        tokens = s.scalar(select(func.coalesce(func.sum(UsageEvent.tokens), 0)).where(
            UsageEvent.user_id == principal.user_id,
            UsageEvent.ts >= now - timedelta(days=1))) or 0
        if tokens >= limits.tokens_per_day:
            raise RateLimitExceeded("Daily usage budget reached. Try again tomorrow.")


def record_usage(principal: Principal, kind: str, tokens: int = 0, *,
                 session: Session | None = None) -> None:
    with optional_session(session) as s:
        s.add(UsageEvent(user_id=principal.user_id, kind=kind[:24], tokens=max(0, int(tokens))))
        s.flush()
