"""Retention purge: itineraries, evaluation runs, usage events and (old) audit rows.

Audit rows younger than AUDIT_RETENTION_DAYS cannot be deleted (database trigger).
Run with --dry-run first.
"""
from __future__ import annotations

import argparse
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import delete, func, select  # noqa: E402

from config.settings import get_settings  # noqa: E402
from db.models import AuditLog, EvaluationRun, Itinerary, UsageEvent, utcnow  # noqa: E402
from db.session import init_db, session_scope  # noqa: E402
from security import audit  # noqa: E402
from security.logging_setup import configure_logging  # noqa: E402


def main() -> int:
    s = get_settings()
    parser = argparse.ArgumentParser(description="Purge data past its retention period.")
    parser.add_argument("--days", type=int, default=s.data_retention_days,
                        help="retention for itineraries/eval runs/usage (default from env)")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.days < 1:
        print("--days must be >= 1", file=sys.stderr)
        return 2
    configure_logging(s.log_level)
    init_db()
    now = utcnow()
    targets = [
        ("itineraries", Itinerary, Itinerary.created_at, now - timedelta(days=args.days)),
        ("evaluation_runs", EvaluationRun, EvaluationRun.ts, now - timedelta(days=args.days)),
        ("usage_events", UsageEvent, UsageEvent.ts, now - timedelta(days=args.days)),
        ("audit_log", AuditLog, AuditLog.ts, now - timedelta(days=s.audit_retention_days)),
    ]
    summary: dict[str, int] = {}
    with session_scope() as session:
        for name, model, col, cutoff in targets:
            count = session.scalar(select(func.count()).select_from(model).where(col < cutoff)) or 0
            summary[name] = count
            if count and not args.dry_run:
                session.execute(delete(model).where(col < cutoff))
        if not args.dry_run:
            audit.record("retention:purge", "success", resource="database",
                         detail=", ".join(f"{k}={v}" for k, v in summary.items()), session=session)
    print(("DRY RUN - would delete: " if args.dry_run else "Deleted: ") + str(summary))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
