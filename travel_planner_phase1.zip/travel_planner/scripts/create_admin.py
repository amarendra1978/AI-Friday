"""Create the first (or an additional) admin. Prompts for the password; never takes it as an argument."""
from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import get_settings  # noqa: E402
from db.session import init_db  # noqa: E402
from security.logging_setup import configure_logging  # noqa: E402
from security.passwords import validate_password_policy  # noqa: E402
from security.users import UserError, bootstrap_admin, normalize_username  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Create an admin user.")
    parser.add_argument("--username", required=True)
    args = parser.parse_args()
    configure_logging(get_settings().log_level)
    username = normalize_username(args.username)

    password = getpass.getpass("Password: ")
    problems = validate_password_policy(password, username=username)
    if problems:
        print("Password rejected: " + "; ".join(problems), file=sys.stderr)
        return 2
    if password != getpass.getpass("Confirm password: "):
        print("Passwords do not match.", file=sys.stderr)
        return 2

    init_db()
    try:
        user_id = bootstrap_admin(username, password)
    except UserError as exc:
        print(f"Could not create admin: {exc}", file=sys.stderr)
        return 1
    print(f"Admin '{username}' created (id={user_id}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
