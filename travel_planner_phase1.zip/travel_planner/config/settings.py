"""Application settings, read from the environment (and .env in development).

Secrets are never given defaults and are excluded from ``repr``.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
_TRUE = {"1", "true", "yes", "on"}


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    return default if raw is None or raw.strip() == "" else raw.strip().lower() in _TRUE


def _env_int(name: str, default: int, *, lo: int, hi: int) -> int:
    raw = os.getenv(name)
    try:
        value = int(raw) if raw not in (None, "") else default
    except ValueError:
        value = default
    return max(lo, min(hi, value))


@dataclass(frozen=True, slots=True)
class RoleLimits:
    """Cost controls per role."""

    generations_per_hour: int
    tokens_per_day: int


# Budget cap per role (keys are Role values; kept as str to avoid an import cycle).
ROLE_LIMITS: dict[str, RoleLimits] = {
    "admin": RoleLimits(60, 400_000),
    "planner": RoleLimits(30, 200_000),
    "traveler": RoleLimits(10, 60_000),
    "auditor": RoleLimits(0, 0),
}


@dataclass(frozen=True, slots=True)
class Settings:
    llm_base_url: str
    llm_api_key: str = field(repr=False)
    llm_verify_ssl: bool
    llm_ca_bundle: str | None
    generator_model: str
    judge_model: str
    embedding_model: str
    use_embeddings: bool
    llm_timeout_s: float
    llm_max_retries: int
    max_output_tokens: int
    database_url: str
    session_idle_minutes: int
    max_failed_logins: int
    lockout_minutes: int
    audit_retention_days: int
    data_retention_days: int
    log_level: str
    data_dir: Path
    eval_dir: Path
    guardrails_path: Path


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings once per process. Call ``get_settings.cache_clear()`` in tests."""
    load_dotenv(PROJECT_ROOT / ".env", override=False)
    return Settings(
        llm_base_url=os.getenv("LLM_BASE_URL", "https://genailab.tcs.in").rstrip("/"),
        llm_api_key=os.getenv("LLM_API_KEY", ""),
        # Spec default is false (enterprise cert). Set LLM_CA_BUNDLE to verify properly.
        llm_verify_ssl=_env_bool("LLM_VERIFY_SSL", False),
        llm_ca_bundle=os.getenv("LLM_CA_BUNDLE") or None,
        generator_model=os.getenv("GENERATOR_MODEL", "azure/genailab-maas-gpt-35-turbo"),
        judge_model=os.getenv("JUDGE_MODEL", "azure/genailab-maas-gpt-4o"),
        embedding_model=os.getenv("EMBEDDING_MODEL", "azure/genailab-maas-text-embedding-3-large"),
        use_embeddings=_env_bool("USE_EMBEDDINGS", False),
        llm_timeout_s=float(_env_int("LLM_TIMEOUT_SECONDS", 60, lo=5, hi=300)),
        llm_max_retries=_env_int("LLM_MAX_RETRIES", 2, lo=0, hi=4),
        max_output_tokens=_env_int("LLM_MAX_OUTPUT_TOKENS", 1500, lo=100, hi=8000),
        database_url=os.getenv("DATABASE_URL", "sqlite:///./travel_planner.db"),
        session_idle_minutes=_env_int("SESSION_IDLE_MINUTES", 30, lo=1, hi=480),
        max_failed_logins=_env_int("MAX_FAILED_LOGINS", 5, lo=3, hi=20),
        lockout_minutes=_env_int("LOCKOUT_MINUTES", 15, lo=1, hi=1440),
        audit_retention_days=_env_int("AUDIT_RETENTION_DAYS", 365, lo=30, hi=3650),
        data_retention_days=_env_int("DATA_RETENTION_DAYS", 180, lo=1, hi=3650),
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        data_dir=Path(os.getenv("DATA_DIR", PROJECT_ROOT / "data")),
        eval_dir=Path(os.getenv("EVAL_DIR", PROJECT_ROOT / "eval")),
        guardrails_path=Path(
            os.getenv("GUARDRAILS_PATH", PROJECT_ROOT / "security" / "guardrails.yaml")
        ),
    )
