"""Canonical traveler-preference schema shared by the UI, graph, guardrails and eval data."""
from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Pace = Literal["relaxed", "moderate", "packed"]
GroupType = Literal["solo", "couple", "family", "friends", "business"]
Mobility = Literal["none", "limited", "wheelchair"]

# Daily activity-hour ceilings per pace (used by the scheduler and the eval constraint check).
PACE_MAX_ACTIVITY_HOURS: dict[str, float] = {"relaxed": 5.0, "moderate": 7.0, "packed": 9.0}


class Preferences(BaseModel):
    """Traveler preferences. Numeric limits are enforced by guardrails (from guardrails.yaml)."""

    model_config = ConfigDict(extra="ignore")

    destination: str = "Paris"
    days: int = 3
    budget_usd: float = 500.0  # total per traveler, excluding accommodation
    interests: list[str] = Field(default_factory=list)
    pace: Pace = "moderate"
    group_type: GroupType = "solo"
    dietary: list[str] = Field(default_factory=list)
    mobility: Mobility = "none"
    start_date: date | None = None
    hotel: str | None = None
    free_text: str = ""

    @field_validator("interests", "dietary", mode="before")
    @classmethod
    def _clean_list(cls, v: object) -> list[str]:
        if v is None:
            return []
        if isinstance(v, str):
            v = [p for p in v.split(",")]
        return [str(x).strip().lower() for x in v if str(x).strip()]

    @field_validator("destination", mode="before")
    @classmethod
    def _clean_dest(cls, v: object) -> str:
        return str(v).strip()
