"""Resilient LLM calls: retries with backoff, <think> stripping, JSON-only structured output."""
from __future__ import annotations

import json
import logging
import random
import re
import ssl
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import httpx
import openai
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, ValidationError

from config.settings import get_settings

logger = logging.getLogger(__name__)

_THINK = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)
_THINK_OPEN = re.compile(r"<think>.*\Z", re.DOTALL | re.IGNORECASE)
_FENCE = re.compile(r"^```[a-zA-Z0-9_-]*\s*|\s*```$")


class LLMCallError(RuntimeError):
    """Infrastructure failure. ``user_message`` is generic and safe to show in the UI."""

    def __init__(self, kind: str, user_message: str) -> None:
        super().__init__(kind)
        self.kind = kind
        self.user_message = user_message


class StructuredOutputError(RuntimeError):
    """Model never produced valid JSON for the schema and no fallback was supplied."""


def _chain(exc: BaseException) -> list[BaseException]:
    seen: list[BaseException] = []
    cur: BaseException | None = exc
    while cur is not None and cur not in seen and len(seen) < 8:
        seen.append(cur)
        cur = cur.__cause__ or cur.__context__
    return seen


def classify_exception(exc: BaseException) -> tuple[str, bool, str]:
    """Map an exception to (kind, retryable, generic user message)."""
    chain = _chain(exc)
    if any(isinstance(e, openai.AuthenticationError) for e in chain):
        return "auth", False, "The AI service rejected the credentials. Please contact an administrator."
    if any(isinstance(e, openai.PermissionDeniedError) for e in chain):
        return "forbidden", False, "Access to the AI model was denied. Please contact an administrator."
    if any(isinstance(e, openai.RateLimitError) for e in chain):
        return "rate_limited", True, "The AI service is busy. Please try again shortly."
    if any(isinstance(e, ssl.SSLError) or "CERTIFICATE_VERIFY_FAILED" in str(e) for e in chain):
        return "tls", False, "A secure connection to the AI service could not be established."
    if any(isinstance(e, (openai.APITimeoutError, httpx.TimeoutException)) for e in chain):
        return "timeout", True, "The AI service took too long to respond. Please try again."
    if any(isinstance(e, openai.APIStatusError) and getattr(e, "status_code", 0) >= 500 for e in chain):
        return "server", True, "The AI service had a temporary problem. Please try again."
    if any(isinstance(e, (openai.APIConnectionError, httpx.TransportError)) for e in chain):
        return "network", True, "The AI service could not be reached. Please try again."
    return "unknown", False, "Something went wrong while contacting the AI service."


def _sleep(seconds: float) -> None:  # separate function so tests can patch it
    time.sleep(seconds)


def message_text(msg: BaseMessage) -> str:
    """Flatten message content (str or list of parts) to text."""
    content = msg.content
    if isinstance(content, str):
        return content
    return "".join(p if isinstance(p, str) else str(p.get("text", "")) for p in content
                   if isinstance(p, (str, dict)))


def call_llm(llm: Any, prompt: str | list[BaseMessage], *, max_attempts: int | None = None) -> AIMessage:
    """Invoke with retries + exponential backoff on 429/5xx/timeouts. 401/403/TLS fail fast."""
    attempts = max_attempts or (get_settings().llm_max_retries + 1)
    last: tuple[str, str] = ("unknown", "Something went wrong while contacting the AI service.")
    for i in range(attempts):
        try:
            return llm.invoke(prompt)
        except Exception as exc:  # noqa: BLE001 - classified below
            kind, retryable, message = classify_exception(exc)
            last = (kind, message)
            logger.warning("llm call failed kind=%s attempt=%d/%d", kind, i + 1, attempts)
            if not retryable or i == attempts - 1:
                break
            _sleep(min(8.0, 2.0 ** i) + random.uniform(0, 0.3))
    raise LLMCallError(*last)


def strip_think(text: str) -> str:
    """Remove reasoning-model ``<think>`` blocks (closed, unclosed, or close-tag-only)."""
    text = _THINK.sub("", text)
    if "</think>" in text.lower():
        text = re.split(r"</think>", text, flags=re.IGNORECASE)[-1]
    return _THINK_OPEN.sub("", text).strip()


def extract_json(text: str) -> Any:
    """Parse the first JSON object/array in ``text`` after removing think blocks and fences."""
    cleaned = _FENCE.sub("", strip_think(text).strip()).strip()
    decoder = json.JSONDecoder()
    for m in re.finditer(r"[\{\[]", cleaned):
        try:
            value, _ = decoder.raw_decode(cleaned[m.start():])
        except json.JSONDecodeError:
            continue
        return value
    raise ValueError("no JSON found in model output")


@dataclass(slots=True)
class StructuredResult[T: BaseModel]:
    value: T
    attempts: int
    used_fallback: bool
    tokens_in: int = 0
    tokens_out: int = 0
    error_kind: str | None = None


def _summarize(err: ValidationError | ValueError) -> str:
    if isinstance(err, ValidationError):
        return "; ".join(f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in err.errors()[:5])
    return str(err)[:200]


def invoke_structured[T: BaseModel](
    prompt: str, schema: type[T], *, llm: Any, system: str | None = None,
    fallback: T | Callable[[], T] | None = None, max_corrections: int = 2,
) -> StructuredResult[T]:
    """Ask for JSON-only output, validate with pydantic, feed errors back (up to 2 retries).

    If the model never complies (or the service is unavailable) and ``fallback`` is given,
    returns it with ``used_fallback=True``; otherwise raises.
    """
    schema_json = json.dumps(schema.model_json_schema(), separators=(",", ":"))
    sys_text = (system or "") + ("\n\n" if system else "") + (
        "Respond with ONLY a single JSON object matching the schema. No prose, no markdown, "
        "no code fences.")
    messages: list[BaseMessage] = [SystemMessage(content=sys_text),
                                   HumanMessage(content=f"{prompt}\n\nJSON schema:\n{schema_json}")]
    tokens_in = tokens_out = 0
    error_kind: str | None = None
    attempts = 0
    for attempts in range(1, max_corrections + 2):
        try:
            resp = call_llm(llm, messages)
        except LLMCallError as exc:
            error_kind = exc.kind
            if fallback is None:
                raise
            break
        usage = getattr(resp, "usage_metadata", None) or {}
        tokens_in += int(usage.get("input_tokens", 0))
        tokens_out += int(usage.get("output_tokens", 0))
        raw = message_text(resp)
        try:
            value = schema.model_validate(extract_json(raw))
            return StructuredResult(value, attempts, False, tokens_in, tokens_out)
        except (ValidationError, ValueError) as err:
            error_kind = "invalid_output"
            logger.info("structured output invalid attempt=%d schema=%s", attempts, schema.__name__)
            messages += [AIMessage(content=raw[:2000]),
                         HumanMessage(content=f"That reply was invalid: {_summarize(err)}. "
                                              "Return ONLY the corrected JSON object.")]
    if fallback is None:
        raise StructuredOutputError(f"No valid {schema.__name__} after {attempts} attempts")
    value = fallback() if callable(fallback) else fallback
    return StructuredResult(value, attempts, True, tokens_in, tokens_out, error_kind)
