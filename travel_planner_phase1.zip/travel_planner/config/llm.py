"""LLM / embedding factories. Every model goes through the same enterprise endpoint."""
from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path

import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from pydantic import SecretStr

from config.models import require_chat_model
from config.settings import Settings, get_settings
from security import audit
from security.logging_setup import register_secret
from security.rbac import Principal, require_permission

logger = logging.getLogger(__name__)
GENERATOR_TEMPERATURE = 0.2
JUDGE_TEMPERATURE = 0.0


class MissingApiKeyError(RuntimeError):
    """No LLM_API_KEY configured and no admin override supplied."""


class EmbeddingsDisabledError(RuntimeError):
    """get_embeddings() called while USE_EMBEDDINGS is false."""


def tls_verify_setting(settings: Settings | None = None) -> bool | str:
    """``True``/``False``, or a CA-bundle path. LLM_CA_BUNDLE wins over LLM_VERIFY_SSL."""
    s = settings or get_settings()
    if s.llm_ca_bundle:
        if not Path(s.llm_ca_bundle).is_file():
            raise FileNotFoundError("LLM_CA_BUNDLE does not point to a file")
        return s.llm_ca_bundle
    return s.llm_verify_ssl


def is_insecure_tls(settings: Settings | None = None) -> bool:
    """True when TLS verification is disabled (admins see a badge for this)."""
    return tls_verify_setting(settings) is False


def warn_if_insecure() -> None:
    if is_insecure_tls():
        logger.warning("LLM_VERIFY_SSL=false: TLS verification is DISABLED for the LLM endpoint. "
                       "Set LLM_CA_BUNDLE to the corporate CA and LLM_VERIFY_SSL=true.")


@lru_cache(maxsize=4)
def _http_client(verify: bool | str, timeout: float) -> httpx.Client:
    # verify=False is only used for the enterprise endpoint (controlled by LLM_VERIFY_SSL).
    return httpx.Client(verify=verify, timeout=timeout)  # nosec B501


def _resolve_key(api_key: str | None) -> str:
    key = api_key or get_settings().llm_api_key
    if not key:
        raise MissingApiKeyError("LLM_API_KEY is not configured")
    register_secret(key)
    return key


def get_llm(model_name: str | None = None, role: str = "generator", *, api_key: str | None = None,
            max_tokens: int | None = None) -> ChatOpenAI:
    """Build a chat model. ``temperature`` is omitted for models that reject it."""
    s = get_settings()
    name = model_name or (s.judge_model if role == "judge" else s.generator_model)
    info = require_chat_model(name)
    kwargs: dict = {
        "base_url": s.llm_base_url,
        "model": name,
        "api_key": SecretStr(_resolve_key(api_key)),
        "http_client": _http_client(tls_verify_setting(s), s.llm_timeout_s),
        "timeout": s.llm_timeout_s,
        "max_retries": 0,  # retries/backoff are handled in config.structured.call_llm
        "max_tokens": max_tokens or s.max_output_tokens,
    }
    if info.supports_temperature:
        kwargs["temperature"] = JUDGE_TEMPERATURE if role == "judge" else GENERATOR_TEMPERATURE
    return ChatOpenAI(**kwargs)


def get_judge_llm(model_name: str | None = None, *, api_key: str | None = None) -> ChatOpenAI:
    """Judge model (default JUDGE_MODEL), temperature 0 where supported."""
    return get_llm(model_name, role="judge", api_key=api_key)


def get_embeddings(*, api_key: str | None = None) -> OpenAIEmbeddings:
    """Embedding model; only available when USE_EMBEDDINGS=true."""
    s = get_settings()
    if not s.use_embeddings:
        raise EmbeddingsDisabledError("Embeddings are disabled (USE_EMBEDDINGS=false)")
    return OpenAIEmbeddings(
        base_url=s.llm_base_url, model=s.embedding_model,
        api_key=SecretStr(_resolve_key(api_key)),
        http_client=_http_client(tls_verify_setting(s), s.llm_timeout_s),
        check_embedding_ctx_length=False,
    )


@require_permission("model:configure")
def test_connection(principal: Principal, *, api_key: str | None = None) -> dict[str, str]:
    """Admin-only: ping generator and judge (and embeddings if enabled). Generic results only."""
    from config.structured import call_llm, classify_exception

    s = get_settings()
    results: dict[str, str] = {}

    def _ping(label: str, name: str, role: str) -> None:
        try:
            call_llm(get_llm(name, role, api_key=api_key, max_tokens=8), "Reply with: ok",
                     max_attempts=1)
            results[label] = "ok"
        except MissingApiKeyError:
            results[label] = "No API key configured"
        except Exception as exc:  # noqa: BLE001 - mapped to a generic message
            results[label] = classify_exception(exc)[2]

    _ping("generator", s.generator_model, "generator")
    _ping("judge", s.judge_model, "judge")
    if s.use_embeddings:
        try:
            get_embeddings(api_key=api_key).embed_query("connection test")
            results["embeddings"] = "ok"
        except Exception as exc:  # noqa: BLE001
            results["embeddings"] = classify_exception(exc)[2]
    audit.record("model:test_connection", "success" if all(v == "ok" for v in results.values())
                 else "failure", principal=principal, resource="llm_endpoint",
                 flags=[f"{k}:{'ok' if v == 'ok' else 'fail'}" for k, v in results.items()])
    return results
