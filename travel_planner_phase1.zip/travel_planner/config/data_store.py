"""Read-only, schema-validated access to the sample data. Fails closed on invalid data."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, ValidationError, model_validator

from config.schemas import Preferences
from config.settings import get_settings

HHMM = Annotated[str, StringConstraints(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")]
Slug = Annotated[str, StringConstraints(pattern=r"^[a-z0-9_-]{2,40}$")]
Category = Literal["museum", "landmark", "park", "food", "market", "temple", "neighborhood", "activity"]


class DataValidationError(RuntimeError):
    """A data file is missing or invalid. The app must not start with bad data."""


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class OpeningHours(_Strict):
    open: HHMM
    close: HHMM

    @model_validator(mode="after")
    def _ordered(self) -> "OpeningHours":
        if self.close <= self.open:
            raise ValueError("close must be after open")
        return self


class Place(_Strict):
    id: Slug
    name: Annotated[str, StringConstraints(min_length=2, max_length=120)]
    category: Category
    lat: Annotated[float, Field(ge=-90, le=90)]
    lng: Annotated[float, Field(ge=-180, le=180)]
    avg_visit_hours: Annotated[float, Field(ge=0.25, le=8)]
    cost: Annotated[float, Field(ge=0, le=1000)]  # USD per person
    opening_hours: OpeningHours
    setting: Literal["indoor", "outdoor", "mixed"]
    best_time_of_day: Literal["morning", "afternoon", "evening", "any"]
    tags: tuple[str, ...] = ()


class Hotel(_Strict):
    name: str
    lat: Annotated[float, Field(ge=-90, le=90)]
    lng: Annotated[float, Field(ge=-180, le=180)]


class City(_Strict):
    id: Slug
    name: str
    country: str
    currency: str = "USD"
    default_hotel: Hotel
    places: tuple[Place, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique_ids(self) -> "City":
        ids = [p.id for p in self.places]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate place ids")
        return self


class DestinationsFile(_Strict):
    version: str
    notice: str
    cities: tuple[City, ...] = Field(min_length=1)


class TransportMode(_Strict):
    name: Slug
    avg_speed_kmh: Annotated[float, Field(gt=0, le=200)]
    cost_per_km: Annotated[float, Field(ge=0)]
    base_fare: Annotated[float, Field(ge=0)] = 0.0
    max_comfortable_km: float | None = None


class Schedule(_Strict):
    first: HHMM
    last: str
    headway_min: Annotated[int, Field(ge=1, le=180)]


class TransportFile(_Strict):
    modes: tuple[TransportMode, ...]
    schedules: dict[str, Schedule]
    city_modes: dict[str, tuple[str, ...]]

    @model_validator(mode="after")
    def _consistent(self) -> "TransportFile":
        names = {m.name for m in self.modes}
        for city, modes in self.city_modes.items():
            if not set(modes) <= names:
                raise ValueError(f"city_modes[{city}] references unknown mode")
        if not set(self.schedules) <= names:
            raise ValueError("schedules reference unknown mode")
        return self


class SampleProfile(_Strict):
    name: str
    preferences: Preferences


class Expectations(_Strict):
    """What the evaluation expects for a benchmark case."""

    max_budget_usd: float | None = None
    max_daily_hours: float | None = None
    must_cover_interests: tuple[str, ...] = ()
    expect_block: bool = False
    expected_flags: tuple[str, ...] = ()


class BenchmarkCase(Preferences):
    model_config = ConfigDict(extra="forbid")

    id: Slug
    category: Literal["standard", "adversarial"]
    expect: Expectations


class DataStore:
    """Immutable view over the validated data files."""

    def __init__(self, destinations: DestinationsFile, transport: TransportFile, data_dir: Path) -> None:
        self._dest = destinations
        self.transport = transport
        self._data_dir = data_dir.resolve()
        self._by_id = {c.id: c for c in destinations.cities}

    @property
    def cities(self) -> tuple[City, ...]:
        return self._dest.cities

    @property
    def notice(self) -> str:
        return self._dest.notice

    def city_ids(self) -> list[str]:
        return list(self._by_id)

    def resolve_city(self, id_or_name: str) -> City | None:
        key = id_or_name.strip().casefold()
        for c in self._dest.cities:
            if key in (c.id.casefold(), c.name.casefold()):
                return c
        return None

    def city(self, city_id: str) -> City | None:
        return self._by_id.get(city_id)

    def guide_text(self, city_id: str) -> str:
        """Return the guide markdown for a known city; path is derived only from validated ids."""
        if city_id not in self._by_id:
            raise DataValidationError("Unknown destination")
        path = (self._data_dir / "guides" / f"{city_id}.md").resolve()
        if not path.is_relative_to(self._data_dir):
            raise DataValidationError("Invalid guide path")
        try:
            return path.read_text(encoding="utf-8")
        except OSError:
            raise DataValidationError("Guide missing") from None


def _read_json(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        raise DataValidationError(f"Cannot read data file {path.name}") from None


def load_data_store(data_dir: Path | None = None) -> DataStore:
    """Load and validate all data files; any problem raises :class:`DataValidationError`."""
    base = Path(data_dir or get_settings().data_dir)
    try:
        dest = DestinationsFile.model_validate(_read_json(base / "destinations.json"))
        transport = TransportFile.model_validate(_read_json(base / "transport.json"))
    except ValidationError as exc:
        raise DataValidationError(f"Data validation failed ({exc.error_count()} errors)") from None
    store = DataStore(dest, transport, base)
    for city in dest.cities:
        store.guide_text(city.id)  # every city must have a guide
        if city.id not in transport.city_modes:
            raise DataValidationError(f"No transport modes for {city.id}")
    return store


def load_sample_profiles(data_dir: Path | None = None) -> list[SampleProfile]:
    base = Path(data_dir or get_settings().data_dir)
    try:
        return [SampleProfile.model_validate(x) for x in _read_json(base / "sample_preferences.json")]  # type: ignore[union-attr]
    except (ValidationError, TypeError):
        raise DataValidationError("Invalid sample_preferences.json") from None


def load_benchmark_cases(eval_dir: Path | None = None) -> list[BenchmarkCase]:
    base = Path(eval_dir or get_settings().eval_dir)
    try:
        cases = [BenchmarkCase.model_validate(x) for x in _read_json(base / "benchmark_cases.json")]  # type: ignore[union-attr]
    except (ValidationError, TypeError):
        raise DataValidationError("Invalid benchmark_cases.json") from None
    if len({c.id for c in cases}) != len(cases):
        raise DataValidationError("Duplicate benchmark case ids")
    return cases


@lru_cache(maxsize=1)
def get_data_store() -> DataStore:
    """Process-wide cached store."""
    return load_data_store()
