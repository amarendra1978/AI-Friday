"""Model registry. Only models with the "chat" capability may be generator or judge."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict

Capability = Literal["chat", "embedding", "audio", "vision"]


class ModelInfo(BaseModel):
    """One model exposed by the enterprise endpoint."""

    model_config = ConfigDict(frozen=True)

    name: str
    family: str
    capabilities: tuple[Capability, ...]
    supports_temperature: bool = True
    notes: str = ""


class UnknownModelError(ValueError):
    """Model name is not in the registry."""


class NotAChatModelError(ValueError):
    """Model exists but cannot be used for chat."""


def _chat(name: str, family: str, *, temp: bool = True, notes: str = "") -> ModelInfo:
    return ModelInfo(name=name, family=family, capabilities=("chat",),
                     supports_temperature=temp, notes=notes)


_REASONING = "Reasoning-style model: rejects temperature; <think> blocks stripped."

MODEL_REGISTRY: tuple[ModelInfo, ...] = (
    _chat("azure/genailab-maas-gpt-35-turbo", "openai", notes="Default generator."),
    _chat("azure/genailab-maas-gpt-4o", "openai", notes="Default judge."),
    _chat("azure/genailab-maas-gpt-4o-mini", "openai"),
    _chat("azure/genailab-maas-gpt-4.1", "openai"),
    _chat("azure/genailab-maas-gpt-4.1-mini", "openai"),
    _chat("azure/genailab-maas-gpt-4.1-nano", "openai"),
    _chat("azure/genailab-maas-gpt-5-mini", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.0", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.1", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.2", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.4", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.4-mini", "openai", temp=False, notes=_REASONING),
    _chat("genailab-maas-gpt-5.4-nano", "openai", temp=False, notes=_REASONING),
    _chat("azure_ai/genailab-maas-DeepSeek-R1", "deepseek", temp=False, notes=_REASONING),
    _chat("azure_ai/genailab-maas-DeepSeek-V3-0324", "deepseek"),
    _chat("azure_ai/genailab-maas-Llama-3.3-70B-Instruct", "meta"),
    _chat("azure_ai/genailab-maas-Llama-4-Maverick-17B-128E-Instruct-FP8", "meta"),
    _chat("gemini-3.1-pro-preview", "google"),
    _chat("gemini-3-flash-preview", "google"),
    _chat("gemini-2.5-flash", "google"),
    _chat("gemini-2.5-pro", "google"),
    _chat("gemini-2.0-flash-001", "google"),
    ModelInfo(name="azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct", family="meta",
              capabilities=("chat", "vision"), notes="Vision; not used by default."),
    ModelInfo(name="azure_ai/genailab-maas-Phi-3.5-vision-instruct", family="microsoft",
              capabilities=("chat", "vision"), notes="Vision; not used by default."),
    ModelInfo(name="genailab-maas-gpt-5.2-codex", family="openai", capabilities=("chat",),
              supports_temperature=False, notes="Code model; not used."),
    ModelInfo(name="genailab-maas-gpt-5.3-codex", family="openai", capabilities=("chat",),
              supports_temperature=False, notes="Code model; not used."),
    ModelInfo(name="azure/genailab-maas-text-embedding-3-large", family="openai",
              capabilities=("embedding",), supports_temperature=False),
    ModelInfo(name="azure/genailab-maas-whisper", family="openai",
              capabilities=("audio",), supports_temperature=False, notes="Audio; not used."),
)

# Models that are registered but deliberately not selectable (vision/code are "not used").
NOT_SELECTABLE: frozenset[str] = frozenset({
    "azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct",
    "azure_ai/genailab-maas-Phi-3.5-vision-instruct",
    "genailab-maas-gpt-5.2-codex",
    "genailab-maas-gpt-5.3-codex",
})

DEFAULT_GENERATOR = "azure/genailab-maas-gpt-35-turbo"
DEFAULT_JUDGE = "azure/genailab-maas-gpt-4o"
JUDGE_ALTERNATIVES: tuple[str, ...] = (
    "azure/genailab-maas-gpt-4o",
    "azure/genailab-maas-gpt-4.1",
    "azure/genailab-maas-gpt-4o-mini",
    "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
)
EVAL_CANDIDATE_DEFAULTS: tuple[str, ...] = (
    "azure/genailab-maas-gpt-35-turbo",
    "azure/genailab-maas-gpt-4o-mini",
    "azure/genailab-maas-gpt-4.1-mini",
    "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "azure_ai/genailab-maas-DeepSeek-V3-0324",
    "gemini-2.5-flash",
)
# Planners may only choose a generator from this allow-list (cheap, non-reasoning models).
PLANNER_GENERATOR_ALLOWLIST: tuple[str, ...] = (
    "azure/genailab-maas-gpt-35-turbo",
    "azure/genailab-maas-gpt-4o-mini",
    "azure/genailab-maas-gpt-4.1-mini",
    "azure/genailab-maas-gpt-4.1-nano",
    "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "gemini-2.5-flash",
)

_BY_NAME: dict[str, ModelInfo] = {m.name: m for m in MODEL_REGISTRY}


def get_model_info(name: str) -> ModelInfo:
    """Return registry info or raise :class:`UnknownModelError`."""
    try:
        return _BY_NAME[name]
    except KeyError:
        raise UnknownModelError("Unknown model") from None


def is_chat_model(name: str) -> bool:
    info = _BY_NAME.get(name)
    return bool(info and "chat" in info.capabilities and name not in NOT_SELECTABLE)


def require_chat_model(name: str) -> ModelInfo:
    """Return info for a selectable chat model or raise."""
    info = get_model_info(name)
    if not is_chat_model(name):
        raise NotAChatModelError("Model cannot be used for chat generation or judging")
    return info


def chat_models() -> tuple[ModelInfo, ...]:
    """All models that may be chosen as generator or judge."""
    return tuple(m for m in MODEL_REGISTRY if is_chat_model(m.name))


def same_family(a: str, b: str) -> bool:
    return get_model_info(a).family == get_model_info(b).family
