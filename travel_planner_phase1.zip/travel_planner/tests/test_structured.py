"""invoke_structured / call_llm with a mocked LLM (no network)."""
import httpx
import openai
import pytest
from langchain_core.messages import AIMessage
from pydantic import BaseModel

from config import structured as st
from config.structured import (LLMCallError, StructuredOutputError, call_llm, classify_exception,
                               extract_json, invoke_structured, strip_think)


class Plan(BaseModel):
    city: str
    days: int


class FakeLLM:
    """Returns queued replies (str -> AIMessage, Exception -> raised) and records prompts."""

    def __init__(self, *replies):
        self.replies, self.calls = list(replies), []

    def invoke(self, messages):
        self.calls.append(messages)
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return AIMessage(content=reply, usage_metadata={"input_tokens": 10, "output_tokens": 5,
                                                        "total_tokens": 15})


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    monkeypatch.setattr(st, "_sleep", lambda s: None)


def _status_error(cls, code):
    req = httpx.Request("POST", "http://x")
    return cls("boom", response=httpx.Response(code, request=req), body=None)


def test_strip_think_variants():
    assert strip_think("<think>reasoning</think>answer") == "answer"
    assert strip_think("<THINK>a\nb</THINK> ok") == "ok"
    assert strip_think("hidden reasoning</think>answer") == "answer"
    assert strip_think("<think>never closed") == ""


def test_extract_json_fences_prose_and_think():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('Sure! Here you go: {"a": {"b": 2}} Hope that helps') == {"a": {"b": 2}}
    assert extract_json('<think>{"x":0}</think>{"a": 3}') == {"a": 3}
    with pytest.raises(ValueError):
        extract_json("no json here")


def test_success_first_try_and_token_accounting():
    llm = FakeLLM('{"city": "Paris", "days": 3}')
    res = invoke_structured("plan", Plan, llm=llm)
    assert res.value == Plan(city="Paris", days=3)
    assert res.attempts == 1 and not res.used_fallback
    assert (res.tokens_in, res.tokens_out) == (10, 5)


def test_retry_feeds_validation_error_back():
    llm = FakeLLM('{"city": "Paris", "days": "many"}', '```json\n{"city": "Paris", "days": 3}\n```')
    res = invoke_structured("plan", Plan, llm=llm)
    assert res.value.days == 3 and res.attempts == 2
    feedback = llm.calls[1][-1].content
    assert "invalid" in feedback and "days" in feedback
    assert res.tokens_in == 20


def test_fallback_after_three_invalid_replies():
    llm = FakeLLM("garbage", "still garbage", "nope")
    fb = Plan(city="Default", days=1)
    res = invoke_structured("plan", Plan, llm=llm, fallback=fb)
    assert res.used_fallback and res.value is fb and res.attempts == 3
    assert res.error_kind == "invalid_output" and not llm.replies


def test_fallback_callable_and_raise_without_fallback():
    res = invoke_structured("p", Plan, llm=FakeLLM("x", "y", "z"), fallback=lambda: Plan(city="C", days=2))
    assert res.value.city == "C"
    with pytest.raises(StructuredOutputError):
        invoke_structured("p", Plan, llm=FakeLLM("x", "y", "z"))


def test_service_failure_uses_fallback_or_raises():
    err = _status_error(openai.AuthenticationError, 401)
    res = invoke_structured("p", Plan, llm=FakeLLM(err), fallback=Plan(city="F", days=1))
    assert res.used_fallback and res.error_kind == "auth"
    with pytest.raises(LLMCallError):
        invoke_structured("p", Plan, llm=FakeLLM(_status_error(openai.AuthenticationError, 401)))


def test_reasoning_model_output_with_think_block():
    llm = FakeLLM('<think>let me think {"city": "Wrong"}</think>{"city": "Tokyo", "days": 2}')
    assert invoke_structured("p", Plan, llm=llm).value.city == "Tokyo"


def test_rate_limit_retried_then_succeeds():
    llm = FakeLLM(_status_error(openai.RateLimitError, 429), _status_error(openai.RateLimitError, 429), "ok")
    assert call_llm(llm, "hi", max_attempts=3).content == "ok"
    assert len(llm.calls) == 3


@pytest.mark.parametrize("cls,code", [(openai.AuthenticationError, 401), (openai.PermissionDeniedError, 403)])
def test_auth_errors_fail_fast_without_retry(cls, code):
    llm = FakeLLM(_status_error(cls, code), "should not be reached")
    with pytest.raises(LLMCallError):
        call_llm(llm, "hi", max_attempts=3)
    assert len(llm.calls) == 1


def test_retries_exhausted_raises_generic_error():
    llm = FakeLLM(*[_status_error(openai.RateLimitError, 429)] * 3)
    with pytest.raises(LLMCallError) as exc:
        call_llm(llm, "hi", max_attempts=3)
    assert exc.value.kind == "rate_limited" and "429" not in exc.value.user_message


def test_classification():
    assert classify_exception(httpx.ReadTimeout("t"))[:2] == ("timeout", True)
    assert classify_exception(httpx.ConnectError("[SSL: CERTIFICATE_VERIFY_FAILED] bad"))[:2] == ("tls", False)
    assert classify_exception(_status_error(openai.InternalServerError, 503))[:2] == ("server", True)
    assert classify_exception(ValueError("x"))[0] == "unknown"
    wrapped = RuntimeError("outer")
    wrapped.__cause__ = _status_error(openai.RateLimitError, 429)
    assert classify_exception(wrapped)[0] == "rate_limited"
