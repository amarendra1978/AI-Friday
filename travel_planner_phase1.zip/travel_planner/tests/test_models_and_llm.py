import pytest

from config import llm as llm_mod
from config.models import (MODEL_REGISTRY, NOT_SELECTABLE, PLANNER_GENERATOR_ALLOWLIST,
                           EVAL_CANDIDATE_DEFAULTS, JUDGE_ALTERNATIVES, NotAChatModelError,
                           UnknownModelError, chat_models, get_model_info, is_chat_model,
                           require_chat_model)
from config.settings import get_settings

REQUIRED = [
    "azure/genailab-maas-gpt-35-turbo", "azure/genailab-maas-gpt-4o", "azure/genailab-maas-gpt-4o-mini",
    "azure/genailab-maas-gpt-4.1", "azure/genailab-maas-gpt-4.1-mini", "azure/genailab-maas-gpt-4.1-nano",
    "azure/genailab-maas-gpt-5-mini", "genailab-maas-gpt-5.0", "genailab-maas-gpt-5.1",
    "genailab-maas-gpt-5.2", "genailab-maas-gpt-5.4", "genailab-maas-gpt-5.4-mini",
    "genailab-maas-gpt-5.4-nano", "azure_ai/genailab-maas-DeepSeek-R1",
    "azure_ai/genailab-maas-DeepSeek-V3-0324", "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "azure_ai/genailab-maas-Llama-4-Maverick-17B-128E-Instruct-FP8", "gemini-3.1-pro-preview",
    "gemini-3-flash-preview", "gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-001",
    "azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct", "azure_ai/genailab-maas-Phi-3.5-vision-instruct",
    "genailab-maas-gpt-5.2-codex", "genailab-maas-gpt-5.3-codex",
    "azure/genailab-maas-text-embedding-3-large", "azure/genailab-maas-whisper",
]


@pytest.fixture(autouse=True)
def fresh_settings(monkeypatch):
    monkeypatch.setenv("LLM_API_KEY", "test-key-not-real-0000")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def test_registry_complete_and_unique():
    names = [m.name for m in MODEL_REGISTRY]
    assert set(REQUIRED) <= set(names) and len(names) == len(set(names))


def test_only_selectable_chat_models_offered():
    assert is_chat_model("azure/genailab-maas-gpt-35-turbo")
    for name in NOT_SELECTABLE | {"azure/genailab-maas-text-embedding-3-large", "azure/genailab-maas-whisper"}:
        assert not is_chat_model(name)
        with pytest.raises(NotAChatModelError):
            require_chat_model(name)
    with pytest.raises(UnknownModelError):
        get_model_info("made-up-model")
    assert all(is_chat_model(m.name) for m in chat_models())


def test_reasoning_models_flagged_no_temperature():
    for name in ("azure_ai/genailab-maas-DeepSeek-R1", "genailab-maas-gpt-5.1", "azure/genailab-maas-gpt-5-mini"):
        assert not get_model_info(name).supports_temperature
    assert get_model_info("azure/genailab-maas-gpt-4o").supports_temperature


def test_allowlists_reference_valid_chat_models():
    for name in (*PLANNER_GENERATOR_ALLOWLIST, *JUDGE_ALTERNATIVES, *EVAL_CANDIDATE_DEFAULTS):
        assert is_chat_model(name), name
    assert 2 <= len(EVAL_CANDIDATE_DEFAULTS) <= 6


def test_generator_defaults_and_temperature():
    llm = llm_mod.get_llm()
    assert llm.model_name == "azure/genailab-maas-gpt-35-turbo" and llm.temperature == 0.2
    judge = llm_mod.get_judge_llm()
    assert judge.model_name == "azure/genailab-maas-gpt-4o" and judge.temperature == 0.0


def test_temperature_omitted_for_reasoning_models():
    assert llm_mod.get_llm("azure_ai/genailab-maas-DeepSeek-R1").temperature is None


def test_non_chat_and_unknown_models_rejected():
    with pytest.raises(NotAChatModelError):
        llm_mod.get_llm("azure/genailab-maas-text-embedding-3-large")
    with pytest.raises(UnknownModelError):
        llm_mod.get_llm("nope")


def test_missing_key_and_admin_override(monkeypatch):
    monkeypatch.setenv("LLM_API_KEY", "")
    get_settings.cache_clear()
    with pytest.raises(llm_mod.MissingApiKeyError):
        llm_mod.get_llm()
    assert llm_mod.get_llm(api_key="override-key-123456") is not None


def test_key_never_in_repr():
    assert "test-key-not-real" not in repr(get_settings())
    assert "test-key-not-real" not in repr(llm_mod.get_llm())


def test_embeddings_disabled_by_default():
    with pytest.raises(llm_mod.EmbeddingsDisabledError):
        llm_mod.get_embeddings()


def test_tls_settings(monkeypatch, tmp_path):
    monkeypatch.setenv("LLM_VERIFY_SSL", "false")
    monkeypatch.delenv("LLM_CA_BUNDLE", raising=False)
    get_settings.cache_clear()
    assert llm_mod.is_insecure_tls() is True
    ca = tmp_path / "ca.pem"
    ca.write_text("x")
    monkeypatch.setenv("LLM_CA_BUNDLE", str(ca))
    get_settings.cache_clear()
    assert llm_mod.tls_verify_setting() == str(ca) and llm_mod.is_insecure_tls() is False
    monkeypatch.setenv("LLM_CA_BUNDLE", str(tmp_path / "missing.pem"))
    get_settings.cache_clear()
    with pytest.raises(FileNotFoundError):
        llm_mod.tls_verify_setting()
