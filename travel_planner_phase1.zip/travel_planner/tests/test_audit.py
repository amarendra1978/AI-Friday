import json
from datetime import timedelta

import pytest
from sqlalchemy import text

from db.models import AuditImmutableError, AuditLog, utcnow
from db.session import session_scope
from security import audit
from security.rbac import PermissionDenied, Role, add_denial_hook


def test_record_and_list(db, principals):
    admin = principals[Role.ADMIN]
    audit.record("itinerary:create", "success", principal=admin, resource="itinerary:abc",
                 flags=["pii_redacted:email"])
    events = audit.list_events(admin)
    assert len(events) == 1
    e = events[0]
    assert e.user_id == admin.user_id and e.role == "admin" and e.flags == ["pii_redacted:email"]


def test_detail_is_redacted_and_truncated(db, principals):
    audit.record("x", "failure", principal=principals[Role.ADMIN],
                 detail="mail a@b.com key sk-abcdefghijklmnopqrstuv " + "z" * 900)
    e = audit.list_events(principals[Role.ADMIN])[0]
    assert "a@b.com" not in e.detail and "sk-abc" not in e.detail and len(e.detail) <= 500


def test_orm_update_and_delete_are_blocked(db):
    audit.record("a", "success")
    with pytest.raises(AuditImmutableError):
        with session_scope() as s:
            row = s.query(AuditLog).first()
            row.outcome = "tampered"
            s.flush()
    with pytest.raises(AuditImmutableError):
        with session_scope() as s:
            s.delete(s.query(AuditLog).first())
            s.flush()


def test_raw_sql_update_and_recent_delete_blocked_by_triggers(db):
    audit.record("a", "success")
    for stmt in ("UPDATE audit_log SET outcome='x'", "DELETE FROM audit_log"):
        with pytest.raises(Exception, match="audit_log"):
            with session_scope() as s:
                s.execute(text(stmt))


def test_old_rows_can_be_purged(db):
    audit.record("old", "success")
    with session_scope() as s:
        s.execute(text("DROP TRIGGER audit_log_no_update"))  # simulate legacy row insertion
        s.execute(text("UPDATE audit_log SET ts = :t"), {"t": utcnow() - timedelta(days=4000)})
    from db.session import get_engine, install_audit_triggers
    install_audit_triggers(get_engine(), 365)
    with session_scope() as s:
        assert s.execute(text("DELETE FROM audit_log")).rowcount == 1


def test_listing_requires_permission(db, principals):
    for role in (Role.TRAVELER, Role.PLANNER):
        with pytest.raises(PermissionDenied):
            audit.list_events(principals[role])
    audit.list_events(principals[Role.AUDITOR])


def test_export_is_audited_and_csv_injection_guarded(db, principals):
    audit.record("=cmd|' /C calc'!A0", "success", principal=principals[Role.ADMIN])
    csv_text = audit.export_events_csv(principals[Role.AUDITOR])
    assert "'=cmd" in csv_text
    assert any(e.action == "audit:export" for e in audit.list_events(principals[Role.AUDITOR]))
    with pytest.raises(PermissionDenied):
        audit.export_events_csv(principals[Role.PLANNER])


def test_denials_are_audited_via_hook(db, principals):
    audit.install_rbac_hook()
    from security.users import list_users
    with pytest.raises(PermissionDenied):
        list_users(principals[Role.TRAVELER])
    events = audit.list_events(principals[Role.ADMIN], action="access:denied")
    assert events and events[0].outcome == "denied"
    assert "permission:user:manage" in events[0].flags
    assert json.dumps(events[0].flags)
