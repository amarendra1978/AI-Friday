import json
import shutil
from pathlib import Path

import pytest

from config.data_store import (DataValidationError, load_benchmark_cases, load_data_store,
                               load_sample_profiles)

ROOT = Path(__file__).resolve().parent.parent


def _copy(tmp_path: Path) -> Path:
    dst = tmp_path / "data"
    shutil.copytree(ROOT / "data", dst)
    return dst


def test_real_data_loads():
    store = load_data_store(ROOT / "data")
    assert set(store.city_ids()) == {"paris", "tokyo", "jaipur"}
    assert all(len(c.places) >= 8 for c in store.cities)
    assert "## Safety" in store.guide_text("paris")
    assert store.resolve_city("TOKYO").id == "tokyo" and store.resolve_city("nowhere") is None


def test_benchmark_and_profiles_load():
    cases = load_benchmark_cases(ROOT / "eval")
    assert len(cases) == 10 and sum(c.category == "adversarial" for c in cases) == 3
    assert load_sample_profiles(ROOT / "data")


def test_guide_path_traversal_rejected():
    store = load_data_store(ROOT / "data")
    for bad in ("../destinations", "..", "paris/../../etc/passwd", ""):
        with pytest.raises(DataValidationError):
            store.guide_text(bad)


def _mutate(path: Path, fn):
    data = json.loads(path.read_text())
    fn(data)
    path.write_text(json.dumps(data))


@pytest.mark.parametrize("mutation", [
    lambda d: d["cities"][0]["places"][0]["opening_hours"].update(open="9am"),
    lambda d: d["cities"][0]["places"][0]["opening_hours"].update(open="18:00", close="09:00"),
    lambda d: d["cities"][0]["places"][0].update(lat=123.0),
    lambda d: d["cities"][0]["places"][0].update(cost=-5),
    lambda d: d["cities"][0]["places"][0].update(category="casino"),
    lambda d: d["cities"][0]["places"][1].update(id=d["cities"][0]["places"][0]["id"]),
    lambda d: d["cities"][0]["places"][0].update(surprise_field=1),
])
def test_invalid_destinations_fail_closed(tmp_path, mutation):
    data_dir = _copy(tmp_path)
    _mutate(data_dir / "destinations.json", mutation)
    with pytest.raises(DataValidationError):
        load_data_store(data_dir)


def test_missing_or_corrupt_files_fail_closed(tmp_path):
    data_dir = _copy(tmp_path)
    (data_dir / "guides" / "tokyo.md").unlink()
    with pytest.raises(DataValidationError):
        load_data_store(data_dir)
    data_dir = _copy(tmp_path / "b")
    (data_dir / "transport.json").write_text("{not json")
    with pytest.raises(DataValidationError):
        load_data_store(data_dir)


def test_transport_referencing_unknown_mode_rejected(tmp_path):
    data_dir = _copy(tmp_path)
    _mutate(data_dir / "transport.json", lambda d: d["city_modes"].update(paris=["walk", "teleport"]))
    with pytest.raises(DataValidationError):
        load_data_store(data_dir)
