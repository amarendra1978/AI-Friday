"""RBAC allow/deny matrix. EXPECTED is an independent copy of the spec table."""
import pytest

from config.models import PLANNER_GENERATOR_ALLOWLIST
from security.rbac import (Permission, PermissionDenied, Principal, Role, add_denial_hook,
                           allowed_generator_models, can_delete_itinerary, can_select_model,
                           has_permission, permissions_matrix_markdown, require_page_access,
                           require_permission, resolve_itinerary_access, visible_pages)

EXPECTED = {
    "itinerary:create": {"admin", "planner", "traveler"},
    "itinerary:read_own": {"admin", "planner", "traveler"},
    "itinerary:read_all": {"admin", "planner", "auditor"},
    "itinerary:export": {"admin", "planner", "traveler"},
    "model:select": {"admin", "planner"},
    "evaluation:view": {"admin", "planner", "auditor"},
    "evaluation:run": {"admin"},
    "data:manage": {"admin"},
    "user:manage": {"admin"},
    "audit:view": {"admin", "auditor"},
    "config:view_security": {"admin", "auditor"},
    "model:configure": {"admin"},
}
CASES = [(p, r) for p in EXPECTED for r in Role]


def P(role: Role, uid: int = 1) -> Principal:
    return Principal(uid, f"{role.value}_x", role)


def test_expected_covers_every_permission():
    assert set(EXPECTED) == {p.value for p in Permission}


@pytest.mark.parametrize("perm,role", CASES)
def test_has_permission_matrix(perm, role):
    assert has_permission(P(role), perm) is (role.value in EXPECTED[perm])


@pytest.mark.parametrize("perm,role", CASES)
def test_decorator_matches_matrix(perm, role):
    @require_permission(perm)
    def action(principal: Principal) -> str:
        return "ran"

    if role.value in EXPECTED[perm]:
        assert action(P(role)) == "ran"
    else:
        with pytest.raises(PermissionDenied):
            action(P(role))


def test_principal_may_be_keyword():
    @require_permission("audit:view")
    def action(*, principal: Principal) -> str:
        return "ok"

    assert action(principal=P(Role.AUDITOR)) == "ok"
    with pytest.raises(PermissionDenied):
        action(principal=P(Role.TRAVELER))


@pytest.mark.parametrize("bad", [None, "admin", 1, {"role": "admin"}, object()])
def test_deny_by_default_without_real_principal(bad):
    @require_permission("itinerary:create")
    def action(principal) -> str:
        return "ran"

    with pytest.raises(PermissionDenied):
        action(bad)


def test_no_arguments_denied():
    @require_permission("itinerary:create")
    def action() -> str:
        return "ran"

    with pytest.raises(PermissionDenied):
        action()


def test_unknown_role_and_permission_denied():
    forged = Principal(1, "x", "superuser")  # type: ignore[arg-type]
    assert not has_permission(forged, "itinerary:create")
    assert not has_permission(P(Role.ADMIN), "nonexistent:perm")


def test_typo_in_permission_fails_at_decoration_time():
    with pytest.raises(ValueError):
        require_permission("evaluation:runn")


def test_denial_hook_called_and_failure_does_not_allow():
    seen = []
    add_denial_hook(lambda p, perm, target: seen.append((perm, target)))
    add_denial_hook(lambda p, perm, target: 1 / 0)

    @require_permission("user:manage")
    def action(principal: Principal) -> None: ...

    with pytest.raises(PermissionDenied):
        action(P(Role.TRAVELER))
    assert seen and seen[-1][0] == "user:manage"


def test_itinerary_row_level_access():
    trav, other = P(Role.TRAVELER, 10), 11
    assert resolve_itinerary_access(trav, 10).level == "full"
    assert resolve_itinerary_access(trav, other) is None

    planner = P(Role.PLANNER, 20)
    assert resolve_itinerary_access(planner, 20).level == "full"
    assert resolve_itinerary_access(planner, 10, assigned_client_ids={10}).level == "full"
    assert resolve_itinerary_access(planner, 10, assigned_client_ids={99}) is None

    assert resolve_itinerary_access(P(Role.ADMIN, 1), 10).level == "full"
    aud = resolve_itinerary_access(P(Role.AUDITOR, 30), 10)
    assert aud is not None and aud.level == "redacted"
    assert resolve_itinerary_access(P(Role.AUDITOR, 30), 30).level == "redacted"  # no read_own


def test_only_owner_can_delete():
    assert can_delete_itinerary(P(Role.TRAVELER, 5), 5)
    assert not can_delete_itinerary(P(Role.TRAVELER, 5), 6)
    assert not can_delete_itinerary(P(Role.ADMIN, 1), 6)
    assert not can_delete_itinerary(P(Role.AUDITOR, 7), 7)


def test_model_selection_rules():
    assert allowed_generator_models(P(Role.TRAVELER)) == ()
    assert allowed_generator_models(P(Role.AUDITOR)) == ()
    assert allowed_generator_models(P(Role.PLANNER)) == PLANNER_GENERATOR_ALLOWLIST
    assert len(allowed_generator_models(P(Role.ADMIN))) > len(PLANNER_GENERATOR_ALLOWLIST)
    planner = P(Role.PLANNER)
    assert can_select_model(planner, "azure/genailab-maas-gpt-4o-mini")
    assert not can_select_model(planner, "azure/genailab-maas-gpt-4.1")  # not on allow-list
    assert not can_select_model(planner, "azure/genailab-maas-gpt-4o", "judge")
    assert can_select_model(P(Role.ADMIN), "azure/genailab-maas-gpt-4.1", "judge")
    assert not can_select_model(P(Role.ADMIN), "azure/genailab-maas-text-embedding-3-large")


def test_page_visibility_and_access():
    assert visible_pages(P(Role.TRAVELER)) == ["Planner", "My Itineraries"]
    assert "Audit Log" in visible_pages(P(Role.AUDITOR))
    assert "Admin" not in visible_pages(P(Role.AUDITOR))
    assert "Admin" in visible_pages(P(Role.ADMIN))
    with pytest.raises(PermissionDenied):
        require_page_access(P(Role.PLANNER), "Admin")
    with pytest.raises(PermissionDenied):
        require_page_access(P(Role.ADMIN), "Nonexistent Page")
    require_page_access(P(Role.ADMIN), "Admin")


def test_matrix_markdown_has_all_rows():
    md = permissions_matrix_markdown()
    for perm in EXPECTED:
        assert f"| {perm} |" in md
    assert "assigned clients" in md and "redacted" in md
