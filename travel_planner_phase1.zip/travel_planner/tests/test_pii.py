import pytest

from security.pii import contains_pii, detect_pii, luhn_valid, redact


def test_luhn():
    assert luhn_valid("4111 1111 1111 1111")
    assert not luhn_valid("4111 1111 1111 1112")
    assert not luhn_valid("1234")


@pytest.mark.parametrize("text,kind", [
    ("mail me at jane.doe+trip@example.co.uk please", "email"),
    ("my card is 4111 1111 1111 1111 thanks", "card"),
    ("card 4111-1111-1111-1111", "card"),
    ("call +91 98765 43210 tomorrow", "phone"),
    ("phone: 555-123-4567", "phone"),
    ("call me on 9876543210", "phone"),
    ("passport number: K1234567", "passport"),
    ("my passport X9876543 expires soon", "passport"),
    ("SSN 123-45-6789", "national_id"),
    ("aadhaar 1234 5678 9012", "national_id"),
    ("PAN ABCDE1234F", "national_id"),
])
def test_detects(text, kind):
    kinds = {m.kind for m in detect_pii(text)}
    assert kind in kinds, (text, kinds)


@pytest.mark.parametrize("text", [
    "Plan 3 days in Paris with a budget of 1500-2000 dollars",
    "Budget 10000-15000 for the trip",
    "Arrive on 2026-10-06 and leave 2026-10-09",
    "We are 4 adults and 2 kids, visiting for 5 nights",
    "Open 09:00-17:30, ticket costs 22 euros",
    "My passport expires next year",
    "Order number 4111111111111112 is not a card",  # fails Luhn
    "I like temples, markets and food",
])
def test_no_false_positives(text):
    assert not contains_pii(text), detect_pii(text)


def test_redact_replaces_and_counts():
    res = redact("Email a@b.com, card 4111 1111 1111 1111, call +44 20 7946 0958.")
    assert "a@b.com" not in res.text and "4111" not in res.text and "7946" not in res.text
    assert res.counts == {"email": 1, "card": 1, "phone": 1}
    assert "[REDACTED_EMAIL]" in res.text


def test_redact_clean_text_unchanged():
    text = "Two days in Tokyo please"
    res = redact(text)
    assert res.text == text and not res.found


def test_card_not_double_reported_as_phone():
    kinds = [m.kind for m in detect_pii("4111 1111 1111 1111")]
    assert kinds == ["card"]
