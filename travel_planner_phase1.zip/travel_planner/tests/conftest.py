"""Test environment: no network, no real secrets, throwaway DB and encryption key."""
import os

os.environ.setdefault("LLM_API_KEY", "test-key-not-real-0000")
os.environ.setdefault("DATABASE_URL", "sqlite://")
os.environ.setdefault("LLM_VERIFY_SSL", "false")
os.environ.setdefault("DATA_ENCRYPTION_KEY", "kQ0H5uYq3p8mZ1xv2n4b6c7d9e0f1g2h3i4j5k6l7m8=")
os.environ.setdefault("MAX_FAILED_LOGINS", "5")


import pytest  # noqa: E402


@pytest.fixture
def db():
    """Fresh in-memory database with tables and audit triggers for each test."""
    from db.session import configure_engine, init_db

    engine = configure_engine("sqlite://")
    init_db()
    yield
    engine.dispose()


@pytest.fixture
def principals():
    from security.rbac import Principal, Role

    return {r: Principal(i + 1, f"{r.value}_user", r) for i, r in enumerate(Role)}
