import pytest

from db.models import User, utcnow
from db.session import session_scope
from security import audit
from security.auth import GENERIC_FAILURE, authenticate, session_expired
from security.passwords import hash_password, validate_password_policy, verify_password
from security.rbac import PermissionDenied, Role
from security.users import (UserError, bootstrap_admin, change_role, create_user,
                            set_user_active)

GOOD = "Tr0ub4dor&3-horse"


def test_password_policy():
    assert validate_password_policy(GOOD, username="alice") == []
    assert validate_password_policy("short1A!")
    assert validate_password_policy("alllowercaseletters")
    assert validate_password_policy("Contains-alice-9X!", username="alice")
    assert validate_password_policy(("Aa1!" * 30))  # > 72 bytes rejected, not truncated


def test_hash_and_verify():
    h = hash_password(GOOD)
    assert h != GOOD and h.startswith("$2")
    assert verify_password(GOOD, h) and not verify_password("wrong", h)
    assert not verify_password(GOOD, "not-a-hash")


def test_login_success_and_generic_failures(db):
    bootstrap_admin("alice", GOOD)
    ok = authenticate("  Alice ", GOOD)
    assert ok.ok and ok.principal.role == Role.ADMIN
    bad_pw, unknown = authenticate("alice", "wrong-password"), authenticate("nobody", GOOD)
    assert not bad_pw.ok and not unknown.ok
    assert bad_pw.message == unknown.message == GENERIC_FAILURE  # no user enumeration


def test_lockout_after_five_failures_even_with_correct_password(db):
    bootstrap_admin("alice", GOOD)
    for _ in range(5):
        assert not authenticate("alice", "wrong-password").ok
    assert not authenticate("alice", GOOD).ok
    with session_scope() as s:
        user = s.query(User).filter_by(username="alice").one()
        assert user.locked_until and user.locked_until > utcnow()
        user.locked_until = utcnow()  # lock expired
    assert authenticate("alice", GOOD).ok


def test_success_resets_failure_counter(db):
    bootstrap_admin("alice", GOOD)
    for _ in range(4):
        authenticate("alice", "wrong-password")
    assert authenticate("alice", GOOD).ok
    for _ in range(4):
        authenticate("alice", "wrong-password")
    assert authenticate("alice", GOOD).ok  # would be locked if counter had not reset


def test_login_events_audited_without_raw_username(db, principals):
    bootstrap_admin("alice", GOOD)
    authenticate("mallory@evil.com", "x")
    events = audit.list_events(principals[Role.ADMIN], action="auth:login")
    assert events and all("mallory" not in (e.detail + e.resource) for e in events)


def test_inactive_user_cannot_login(db, principals):
    admin_id = bootstrap_admin("alice", GOOD)
    other = create_user(principals[Role.ADMIN], "bob", GOOD, Role.TRAVELER)
    set_user_active(principals[Role.ADMIN], other, False)
    assert not authenticate("bob", GOOD).ok
    assert admin_id


def test_duplicate_username_and_bad_username(db, principals):
    bootstrap_admin("alice", GOOD)
    with pytest.raises(UserError):
        create_user(principals[Role.ADMIN], "alice", GOOD, Role.TRAVELER)
    with pytest.raises(UserError):
        create_user(principals[Role.ADMIN], "bad name!", GOOD, Role.TRAVELER)
    with pytest.raises(UserError):
        create_user(principals[Role.ADMIN], "carol", "weak", Role.TRAVELER)


def test_user_management_requires_admin(db, principals):
    for role in (Role.PLANNER, Role.TRAVELER, Role.AUDITOR):
        with pytest.raises(PermissionDenied):
            create_user(principals[role], "dave", GOOD, Role.TRAVELER)


def test_last_admin_cannot_be_deactivated_or_demoted(db):
    from security.rbac import Principal
    admin_id = bootstrap_admin("alice", GOOD)
    actor = Principal(admin_id, "alice", Role.ADMIN)
    with pytest.raises(UserError):
        set_user_active(actor, admin_id, False)
    with pytest.raises(UserError):
        change_role(actor, admin_id, Role.TRAVELER)


def test_session_expiry():
    assert not session_expired(1000.0, 1000.0 + 29 * 60, 30)
    assert session_expired(1000.0, 1000.0 + 31 * 60, 30)
