# Tokyo Travel Guide

## Culture
Tokyo blends historic temples and shrines with dense modern districts. Each neighbourhood has a distinct character, so group sights by area to avoid long transfers.

## Etiquette
Be quiet on trains and avoid phone calls. At shrines and temples, bow slightly at the entrance and follow signs about photography. Do not eat while walking in many areas; eat near the stall. Tipping is not expected.

## Safety
Tokyo is generally very safe, but stay aware of crowds at Shibuya and Shinjuku at night and keep valuables secure. Know the location of the nearest station in case of earthquake alerts and follow local guidance.

## Food
Markets are best in the morning; izakaya alleys come alive in the evening. Many small places are cash-oriented or have limited seating. Vegetarian and allergy needs can be hard to meet, so carry written notes in Japanese.

## Local Tips
Temples open early and are calmest before 8 am. Large attractions like observation decks are best near sunset. Trains stop around midnight, so plan your return.

## Transport
The metro and rail network is the most efficient way to get around; a prepaid transit card saves time. Taxis are expensive and rarely quicker in rush hour.

## Money-saving
Shrines, parks and street-level districts are free or cheap. Eat set lunches rather than dinners, and use the metro rather than taxis.
