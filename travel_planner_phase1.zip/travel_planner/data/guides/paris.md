# Paris Travel Guide

## Culture
Paris is built around art, cafe life and long meals. Major museums are large; pick one or two per day rather than trying to see everything. Many sights are walkable within central arrondissements.

## Etiquette
Greet shop and cafe staff with "Bonjour" before asking anything. Keep voices low in restaurants and on the metro. Tipping is modest; service is usually included in the bill.

## Safety
Pickpocketing is common around the Eiffel Tower, Louvre queues, Montmartre steps and on crowded metro lines. Keep bags zipped and in front. Be cautious of petition and bracelet scams near tourist sites.

## Food
Try bakeries for breakfast, a market lunch, and an early evening cafe stop. Lunch set menus (formule) are cheaper than dinner. The Marais and Enfants Rouges market are good for casual food.

## Local Tips
Museums are often busiest mid-morning; arrive at opening or late afternoon. Evenings at the river and Montmartre are especially scenic. Some museums close one day a week, so check before going.

## Transport
The metro is the fastest way across the city; walking suits neighbouring sights. Taxis cost more and are slower at peak hours.

## Money-saving
Gardens, church exteriors and neighbourhood walks are free. Combine nearby sights in one day to save on transport.
