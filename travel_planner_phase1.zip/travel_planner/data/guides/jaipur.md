# Jaipur Travel Guide

## Culture
Jaipur, the Pink City, is known for forts, palaces, bazaars and crafts. The old city is compact, while the forts sit on hills outside it.

## Etiquette
Dress modestly, covering shoulders and knees, especially at religious sites. Remove shoes where signs request it. Bargaining is normal in bazaars; stay polite and be ready to walk away.

## Safety
Watch for touts offering guided tours or shop visits, and agree on taxi or auto fares before starting. Drink bottled or filtered water and take care with raw street food if you have a sensitive stomach. Keep valuables out of sight in crowded markets.

## Food
Try local lassi, dal baati churma and street snacks from busy, popular stalls. Evening village-style dinners with folk performances are a popular cultural experience.

## Local Tips
Visit forts early to avoid heat and crowds; midday sun is strong outside winter. Sunset at the hilltop forts is a highlight. Markets get busy in the evening.

## Transport
Taxis and ride apps are the practical choice between sights; buses are cheap but slower. Old-city sights are walkable in the cooler hours.

## Money-saving
Viewpoints and bazaar browsing are free. Some monuments offer combined tickets, so check before buying single entries.
